import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { getApiError } from '../../services/api';
import * as intelligenceService from '../../services/intelligenceService';
import * as orderService from '../../services/orderService';
import { addDays, utcToday } from '../../utils/dates';
import { formatMoney } from '../../utils/format';
import { mapServerErrors } from '../../utils/forms';
import VendorRankingTable from './VendorRankingTable';

const CONFIDENCE_BADGE = {
  High: 'text-bg-success',
  Medium: 'text-bg-warning',
  Low: 'text-bg-danger',
};

function CreateOrderDialog({ request, onClose }) {
  const navigate = useNavigate();

  const [attempt, setAttempt] = useState(0);          // goes up each time the analysis is run again
  const [result, setResult] = useState(null);         // the AI analysis
  const [manual, setManual] = useState(null);         // plain vendor options, used if the analysis is skipped
  const [loadError, setLoadError] = useState('');
  const [vendorId, setVendorId] = useState('');
  const [promised, setPromised] = useState('');
  const [reason, setReason] = useState('');
  const [expandedId, setExpandedId] = useState(null);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  // Run the analysis when the dialog opens (and again when the officer asks)
  useEffect(() => {
    let cancelled = false;

    intelligenceService
      .evaluateRequest(request.id)
      .then((data) => {
        if (cancelled) return;
        setResult(data);
        if (data.vendors.length > 0) {
          const best = data.vendors[0];   // preselect the recommendation
          setVendorId(String(best.vendorId));
          setPromised(addDays(utcToday(), best.leadTimeDays));
        }
      })
      .catch((error) => {
        if (!cancelled) setLoadError(getApiError(error).message);
      });

    return () => {
      cancelled = true;
    };
  }, [request.id, attempt]);

  const recommendedId = result && result.vendors.length > 0 ? result.vendors[0].vendorId : null;
  const choseAnother = recommendedId !== null && vendorId !== '' && Number(vendorId) !== recommendedId;
  const analysing = !result && !manual && !loadError;

  const choose = (id, leadTimeDays) => {
    setVendorId(String(id));
    setPromised(addDays(utcToday(), leadTimeDays));
    setErrors({});
  };

  const rerun = () => {
    setResult(null);
    setManual(null);
    setLoadError('');
    setVendorId('');
    setPromised('');
    setReason('');
    setExpandedId(null);
    setErrors({});
    setAttempt((count) => count + 1);
  };

  // The advice is optional: if the analysis fails, the officer can still choose a vendor
  const continueManually = () => {
    setLoadError('');
    orderService
      .getVendorOptions(request.id)
      .then(setManual)
      .catch((error) => setLoadError(getApiError(error).message));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const found = {};
    if (!vendorId) found.vendorId = 'Select a vendor.';
    if (!promised) found.promisedDeliveryDate = 'Promised delivery date is required.';
    else if (promised < utcToday()) found.promisedDeliveryDate = 'The promised delivery date cannot be in the past.';
    if (choseAnother && !reason.trim()) {
      found.overrideReason = 'Please explain why you are not choosing the recommended vendor.';
    }
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSaving(true);
    try {
      const order = await orderService.createOrder({
        purchaseRequestId: request.id,
        vendorId: Number(vendorId),
        promisedDeliveryDate: promised,
        recommendationLogId: result?.logId ?? null,
        overrideReason: choseAnother ? reason.trim() : null,
      });
      toast.success(`Purchase order ${order.poNumber} created.`);
      navigate(`/orders/${order.id}`);
    } catch (error) {
      const apiError = getApiError(error);
      const serverErrors = mapServerErrors(apiError.errors);
      setErrors(serverErrors);
      toast.error(Object.keys(serverErrors).length > 0 ? 'Please fix the highlighted fields.' : apiError.message);
    } finally {
      setSaving(false);
    }
  };

  const canSubmit = !saving && (Boolean(result?.vendors.length) || Boolean(manual?.length));

  return (
    <>
      <div className="modal d-block" tabIndex={-1} role="dialog" aria-modal="true">
        <div className="modal-dialog modal-xl modal-dialog-scrollable">
          <form className="modal-content" onSubmit={handleSubmit} noValidate>
            <div className="modal-header">
              <h5 className="modal-title">Create purchase order for {request.requestNumber}</h5>
              <button type="button" className="btn-close" aria-label="Close" onClick={onClose} disabled={saving} />
            </div>

            <div className="modal-body">
              {analysing && (
                <div className="text-muted py-4 text-center">
                  Analysing vendors (price, delivery history and rating)...
                </div>
              )}

              {loadError && (
                <div className="alert alert-danger">
                  <div>{loadError}</div>
                  <div className="mt-2 d-flex flex-wrap gap-2">
                    <button type="button" className="btn btn-sm btn-outline-danger" onClick={rerun}>
                      Try again
                    </button>
                    {!manual && (
                      <button type="button" className="btn btn-sm btn-outline-secondary" onClick={continueManually}>
                        Continue without the analysis
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* ---- The analysis ---- */}
              {result && result.vendors.length === 0 && (
                <div className="alert alert-warning">{result.summary}</div>
              )}

              {result && result.vendors.length > 0 && (
                <>
                  <div className="alert alert-info">
                    <div className="fw-semibold">{result.summary}</div>
                    <div className="mt-2">
                      Confidence:{' '}
                      <span className={`badge ${CONFIDENCE_BADGE[result.confidence] || 'text-bg-secondary'}`}>
                        {result.confidence}
                      </span>{' '}
                      <span className="small text-muted">({result.confidenceScore})</span>
                      <span className="ms-3 small text-muted">
                        Weights: price {Math.round(result.weights.price * 100)}%, delivery{' '}
                        {Math.round(result.weights.delivery * 100)}%, rating {Math.round(result.weights.rating * 100)}%
                      </span>
                    </div>
                    <div className="small text-muted mt-1">
                      Confidence reflects how much delivery history the top vendor has and how clear its lead is.
                    </div>
                    <div className="small text-muted mt-1">{result.disclaimer}</div>
                  </div>

                  <VendorRankingTable
                    vendors={result.vendors}
                    weights={result.weights}
                    selectedId={vendorId}
                    onSelect={(vendor) => choose(vendor.vendorId, vendor.leadTimeDays)}
                    expandedId={expandedId}
                    onToggle={(id) => setExpandedId((current) => (current === id ? null : id))}
                  />
                </>
              )}

              {/* ---- The fallback without the analysis ---- */}
              {manual && (
                <div className="mb-3">
                  <div className="alert alert-warning">
                    You are choosing without the analysis. The order will not be linked to a recommendation.
                  </div>
                  {manual.length === 0 ? (
                    <div className="alert alert-danger">
                      No active vendor quotes every item of this request, so an order cannot be created yet.
                    </div>
                  ) : (
                    <>
                      <label htmlFor="manual-vendor" className="form-label">Vendor</label>
                      <select
                        id="manual-vendor"
                        className="form-select"
                        value={vendorId}
                        onChange={(event) => {
                          const option = manual.find((item) => String(item.vendorId) === event.target.value);
                          if (option) choose(option.vendorId, option.leadTimeDays);
                          else setVendorId('');
                        }}
                      >
                        <option value="">Select a vendor...</option>
                        {manual.map((option) => (
                          <option key={option.vendorId} value={option.vendorId}>
                            {option.vendorName} - {formatMoney(option.totalPrice)} - {option.leadTimeDays} day(s)
                          </option>
                        ))}
                      </select>
                    </>
                  )}
                </div>
              )}

              {errors.vendorId && <div className="text-danger small mb-2">{errors.vendorId}</div>}

              {errors.recommendationLogId && (
                <div className="alert alert-warning d-flex justify-content-between align-items-center">
                  <span>{errors.recommendationLogId}</span>
                  <button type="button" className="btn btn-sm btn-outline-secondary" onClick={rerun}>
                    Run analysis again
                  </button>
                </div>
              )}

              {/* ---- Choosing someone other than the recommendation needs a reason ---- */}
              {choseAnother && (
                <div className="alert alert-warning">
                  <div className="fw-semibold">You chose a vendor other than the recommended one.</div>
                  <label htmlFor="override-reason" className="form-label mt-2 mb-1">
                    Reason (required, it is saved with the order decision)
                  </label>
                  <textarea
                    id="override-reason"
                    className={`form-control${errors.overrideReason ? ' is-invalid' : ''}`}
                    rows={2}
                    maxLength={1000}
                    value={reason}
                    onChange={(event) => setReason(event.target.value)}
                  />
                  {errors.overrideReason && <div className="invalid-feedback">{errors.overrideReason}</div>}
                </div>
              )}

              {canSubmit && (
                <div className="row">
                  <div className="col-md-5">
                    <label htmlFor="promised" className="form-label">Promised delivery date</label>
                    <input
                      id="promised"
                      type="date"
                      className={`form-control${errors.promisedDeliveryDate ? ' is-invalid' : ''}`}
                      min={utcToday()}
                      value={promised}
                      onChange={(event) => setPromised(event.target.value)}
                    />
                    {errors.promisedDeliveryDate && <div className="invalid-feedback">{errors.promisedDeliveryDate}</div>}
                  </div>
                </div>
              )}
            </div>

            <div className="modal-footer">
              {result && (
                <button type="button" className="btn btn-outline-secondary me-auto" onClick={rerun} disabled={saving}>
                  Run analysis again
                </button>
              )}
              <button type="button" className="btn btn-outline-secondary" onClick={onClose} disabled={saving}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={!canSubmit}>
                {saving ? 'Creating...' : 'Create order'}
              </button>
            </div>
          </form>
        </div>
      </div>
      <div className="modal-backdrop show" />
    </>
  );
}

// The button on the request page. It only appears when the server says canCreateOrder.
export default function CreateOrderButton({ request }) {
  const [open, setOpen] = useState(false);

  if (!request.permissions.canCreateOrder) return null;

  return (
    <>
      <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>
        Create purchase order
      </button>
      {open && <CreateOrderDialog request={request} onClose={() => setOpen(false)} />}
    </>
  );
}
