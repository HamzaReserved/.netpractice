import { Fragment } from 'react';
import { formatMoney } from '../../utils/format';

// A thin bar for a value between 0 and 100
function ScoreBar({ percent, label }) {
  const value = Math.max(0, Math.min(100, percent));
  const color = value >= 80 ? 'bg-success' : value >= 60 ? 'bg-primary' : 'bg-warning';

  return (
    <div className="d-flex align-items-center gap-2">
      <div className="progress flex-grow-1" style={{ height: 8 }}>
        <div className={`progress-bar ${color}`} style={{ width: `${value}%` }} />
      </div>
      <span className="small fw-semibold text-nowrap" style={{ minWidth: 40 }}>
        {label}
      </span>
    </div>
  );
}

// The ranked vendors, with an expandable "Why?" for each one
export default function VendorRankingTable({ vendors, weights, selectedId, onSelect, expandedId, onToggle }) {
  const factors = [
    { key: 'priceScore', label: 'Price', weight: weights.price, hint: 'How close its total is to the cheapest quote' },
    { key: 'deliveryScore', label: 'Delivery record', weight: weights.delivery, hint: 'Share of recent orders delivered on time' },
    { key: 'ratingScore', label: 'Rating', weight: weights.rating, hint: 'Rating out of 5' },
  ];

  return (
    <div className="table-responsive">
      <table className="table table-hover align-middle">
        <thead className="table-light">
          <tr>
            <th scope="col" />
            <th scope="col">Rank</th>
            <th scope="col">Vendor</th>
            <th scope="col" style={{ minWidth: 150 }} title="Weighted score out of 100">Score</th>
            <th scope="col" className="text-end">Total price</th>
            <th scope="col" className="text-end">Delivery record</th>
            <th scope="col" className="text-end">Rating</th>
            <th scope="col" className="text-end">Lead time</th>
            <th scope="col" />
          </tr>
        </thead>
        <tbody>
          {vendors.map((vendor) => {
            const selected = selectedId === String(vendor.vendorId);
            const expanded = expandedId === vendor.vendorId;

            return (
              <Fragment key={vendor.vendorId}>
                <tr
                  className={selected ? 'table-active' : ''}
                  style={{ cursor: 'pointer' }}
                  onClick={() => onSelect(vendor)}
                >
                  <td>
                    <input
                      type="radio"
                      name="vendor"
                      className="form-check-input"
                      checked={selected}
                      onChange={() => onSelect(vendor)}
                      aria-label={`Choose ${vendor.vendorName}`}
                    />
                  </td>
                  <td className="text-nowrap fw-semibold">#{vendor.rank}</td>
                  <td>
                    {vendor.vendorName} <span className="text-muted small">{vendor.vendorCode}</span>
                    {vendor.isRecommended && <span className="badge text-bg-success ms-2">Recommended</span>}
                  </td>
                  <td>
                    <ScoreBar percent={vendor.totalScore} label={vendor.totalScore.toFixed(1)} />
                  </td>
                  <td className="text-end">{formatMoney(vendor.totalPrice)}</td>
                  <td className="text-end small">
                    {vendor.ordersConsidered === 0 ? (
                      <span className="text-muted">No history</span>
                    ) : (
                      `${vendor.onTimeOrders} of ${vendor.ordersConsidered} on time`
                    )}
                  </td>
                  <td className="text-end">{Number(vendor.rating).toFixed(1)}</td>
                  <td className="text-end">{vendor.leadTimeDays} day(s)</td>
                  <td className="text-end">
                    <button
                      type="button"
                      className="btn btn-sm btn-link"
                      onClick={(event) => {
                        event.stopPropagation();
                        onToggle(vendor.vendorId);
                      }}
                    >
                      {expanded ? 'Hide' : 'Why?'}
                    </button>
                  </td>
                </tr>

                {expanded && (
                  <tr>
                    <td colSpan={9} className="bg-light">
                      <div className="small mb-2">{vendor.explanation}</div>
                      <div className="row g-3">
                        {factors.map((factor) => (
                          <div className="col-12 col-md-4" key={factor.key}>
                            <div className="small text-muted">
                              {factor.label} (weight {Math.round(factor.weight * 100)}%)
                            </div>
                            <ScoreBar
                              percent={vendor[factor.key] * 100}
                              label={`${Math.round(vendor[factor.key] * 100)}%`}
                            />
                            <div className="small text-muted">{factor.hint}</div>
                          </div>
                        ))}
                      </div>
                    </td>
                  </tr>
                )}
              </Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
