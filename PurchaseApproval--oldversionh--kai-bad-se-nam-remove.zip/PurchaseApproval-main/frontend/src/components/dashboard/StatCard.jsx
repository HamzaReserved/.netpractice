import { Link } from 'react-router-dom';
import { formatMoney } from '../../utils/format';

export default function StatCard({ card }) {
  const value = card.isMoney ? formatMoney(card.value) : card.value;
  const tone = ['primary', 'success', 'warning', 'danger', 'secondary'].includes(card.tone)
    ? card.tone
    : 'primary';

  const box = (
    <div className={`card dashboard-stat-card dashboard-stat-card--${tone} h-100`}>
      <div className="card-body">
        <div className="dashboard-stat-label">{card.label}</div>
        <div className="dashboard-stat-value">{value}</div>
      </div>
    </div>
  );

  if (!card.link) return box;

  return (
    <Link to={card.link} className="dashboard-stat-link text-decoration-none text-body d-block h-100">
      {box}
    </Link>
  );
}
