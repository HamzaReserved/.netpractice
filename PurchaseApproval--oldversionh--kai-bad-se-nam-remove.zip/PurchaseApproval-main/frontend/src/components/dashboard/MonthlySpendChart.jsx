import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { formatMoney } from '../../utils/format';

// 12500 becomes 13k, 2300000 becomes 2.3M
function shortNumber(value) {
  const size = Math.abs(value);
  if (size >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
  if (size >= 1000) return `${Math.round(value / 1000)}k`;
  return String(value);
}

// One bar per month, oldest on the left
export default function MonthlySpendChart({ points }) {
  const hasData = points.some((point) => point.amount > 0);

  if (!hasData) {
    return <div className="text-muted text-center py-5">Nothing to show for the last six months.</div>;
  }

  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={points} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="label" />
        <YAxis tickFormatter={shortNumber} width={55} />
        <Tooltip formatter={(value) => [formatMoney(value), 'Amount']} />
        <Bar dataKey="amount" fill="#0d6efd" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
