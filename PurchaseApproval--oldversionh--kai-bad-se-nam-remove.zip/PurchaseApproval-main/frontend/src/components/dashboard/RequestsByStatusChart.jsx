import { Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { statusInfo } from '../../utils/requestStatus';

// A donut: one slice per status that has at least one request
export default function RequestsByStatusChart({ items }) {
  const total = items.reduce((sum, item) => sum + item.count, 0);

  if (total === 0) {
    return <div className="text-muted text-center py-5">No requests yet.</div>;
  }

  const data = items
    .filter((item) => item.count > 0)
    .map((item) => {
      const info = statusInfo(item.status);
      return {
        status: item.status,
        name: info.label,
        count: item.count,
        fill: info.color,
      };
    });

  return (
    <>
      <ResponsiveContainer width="100%" height={280}>
        <PieChart>
          <Pie data={data} dataKey="count" nameKey="name" innerRadius={55} outerRadius={95} paddingAngle={2} />
          <Tooltip />
          <Legend formatter={(value, entry) => `${value} (${entry.payload.count})`} />
        </PieChart>
      </ResponsiveContainer>
      <div className="text-center small text-muted">{total} request(s) in total</div>
    </>
  );
}
