// The statuses of a purchase request, with the label and colours used on screen
export const REQUEST_STATUSES = [
  { value: 'Draft', label: 'Draft', badge: 'text-bg-secondary', color: '#6c757d' },
  { value: 'Submitted', label: 'Submitted', badge: 'text-bg-primary', color: '#0d6efd' },
  { value: 'Approved', label: 'Approved', badge: 'text-bg-success', color: '#198754' },
  { value: 'Rejected', label: 'Rejected', badge: 'text-bg-danger', color: '#dc3545' },
  { value: 'PoCreated', label: 'PO created', badge: 'text-bg-info', color: '#0dcaf0' },
  { value: 'Cancelled', label: 'Cancelled', badge: 'text-bg-warning', color: '#ffc107' },
];

export function statusInfo(status) {
  return (
    REQUEST_STATUSES.find((item) => item.value === status) || {
      value: status,
      label: status,
      badge: 'text-bg-light',
      color: '#adb5bd',
    }
  );
}
