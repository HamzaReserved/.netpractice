import api from './api';

// Load audit history with search, filters and pagination.
export async function getAuditLogs(params) {
  const response = await api.get('/api/auditlogs', { params });
  return response.data.data;
}

// Get the available entity and action filter options.
export async function getAuditFilters() {
  const response = await api.get('/api/auditlogs/filters');
  return response.data.data;
}

// Load AI recommendation decisions.
export async function getAiDecisions(params) {
  const response = await api.get('/api/auditlogs/ai-decisions', { params });
  return response.data.data;
}
