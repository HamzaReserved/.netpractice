import api from './api';

// Returns the paged user list from the API.
export async function getUsers(params) {
  const response = await api.get('/api/users', { params });
  return response.data.data;
}

// Fetch one user by ID.
export async function getUser(id) {
  const response = await api.get(`/api/users/${id}`);
  return response.data.data;
}

// Create a new user.
export async function createUser(user) {
  const response = await api.post('/api/users', user);
  return response.data.data;
}

// Update a user's name, email, role and active status.
export async function updateUser(id, user) {
  const response = await api.put(`/api/users/${id}`, user);
  return response.data.data;
}

// Reset a user's password. The API returns HTTP 204 on success.
export async function resetUserPassword(id, newPassword) {
  await api.post(`/api/users/${id}/reset-password`, { newPassword });
}
