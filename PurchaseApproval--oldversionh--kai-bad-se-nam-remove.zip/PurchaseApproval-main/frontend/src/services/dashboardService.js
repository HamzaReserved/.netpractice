import api from './api';

// Cards, requests by status and the six-month series, already scoped to the logged-in role
export async function getSummary() {
  const response = await api.get('/api/dashboard/summary');
  return response.data.data;
}
