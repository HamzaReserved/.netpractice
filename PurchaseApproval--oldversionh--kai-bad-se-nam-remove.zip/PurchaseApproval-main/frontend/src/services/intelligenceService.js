import api from './api';

// Ranks the vendors for an approved request. The answer includes logId, which is sent back
// when the order is created so the decision can be recorded.
export async function evaluateRequest(purchaseRequestId) {
  const response = await api.post('/api/intelligence/evaluate', { purchaseRequestId });
  return response.data.data;
}
