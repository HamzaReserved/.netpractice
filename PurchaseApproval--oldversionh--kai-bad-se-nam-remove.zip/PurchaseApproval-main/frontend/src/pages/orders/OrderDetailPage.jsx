import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import ConfirmDialog from '../../components/common/ConfirmDialog';
import EmptyState from '../../components/common/EmptyState';
import Loader from '../../components/common/Loader';
import OrderStatusBadge from '../../components/orders/OrderStatusBadge';
import { getApiError } from '../../services/api';
import * as orderService from '../../services/orderService';
import { daysBetween, utcToday } from '../../utils/dates';
import { formatDateOnly, formatMoney } from '../../utils/format';
import { mapServerErrors } from '../../utils/forms';

// The two actions that only need a yes or no
const ACTIONS = {
  send: {
    title: 'Mark as sent',
    message: 'Mark this order as sent to the vendor?',
    confirmText: 'Mark as sent',
    success: 'Purchase order marked as sent.',
    danger: false,
    run: orderService.sendOrder,
  },
  cancel: {
    title: 'Cancel order',
    message: 'Cancel this purchase order? The request goes back to Approved, so a new order can be created.',
    confirmText: 'Cancel order',
    success: 'Purchase order cancelled.',
    danger: true,
    run: orderService.cancelOrder,
  },
};

// The dialog where the officer enters the delivery date
function DeliverDialog({ orderDate, busy, serverError, onSubmit, onCancel }) {
  const today = utcToday();
  const earliest = String(orderDate).slice(0, 10);
  const [date, setDate] = useState(today);
  const [error, setError] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!date) setError('Delivery date is required.');
    else if (date > today) setError('The delivery date cannot be in the future.');
    else if (date < earliest) setError('The delivery date cannot be before the order date.');
    else {
      setError('');
      onSubmit(date);
    }
  };

  const shownError = error || serverError;

  return (
    <>
      <div className="modal d-block" tabIndex={-1} role="dialog" aria-modal="true">
        <div className="modal-dialog modal-dialog-centered">
          <form className="modal-content" onSubmit={handleSubmit} noValidate>
            <div className="modal-header">
              <h5 className="modal-title">Mark as delivered</h5>
              <button type="button" className="btn-close" aria-label="Close" onClick={onCancel} disabled={busy} />
            </div>
            <div className="modal-body">
              <label htmlFor="delivered" className="form-label">Date the goods arrived</label>
              <input
                id="delivered"
                type="date"
                className={`form-control${shownError ? ' is-invalid' : ''}`}
                min={earliest}
                max={today}
                value={date}
                onChange={(event) => setDate(event.target.value)}
              />
              {shownError && <div className="invalid-feedback">{shownError}</div>}
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-outline-secondary" onClick={onCancel} disabled={busy}>
                Cancel
              </button>
              <button type="submit" className="btn btn-success" disabled={busy}>
                {busy ? 'Please wait...' : 'Mark as delivered'}
              </button>
            </div>
          </form>
        </div>
      </div>
      <div className="modal-backdrop show" />
    </>
  );
}

export default function OrderDetailPage() {
  const { id } = useParams();

  const [reload, setReload] = useState(0);
  const [state, setState] = useState(null);   // the answer, remembered with the question it answered
  const [confirm, setConfirm] = useState(null);
  const [delivering, setDelivering] = useState(false);
  const [busy, setBusy] = useState(false);
  const [deliverError, setDeliverError] = useState('');

  useEffect(() => {
    let cancelled = false;
    orderService
      .getOrder(id)
      .then((data) => {
        if (!cancelled) setState({ id, reload, data, error: null });
      })
      .catch((err) => {
        if (!cancelled) setState({ id, reload, data: null, error: getApiError(err) });
      });
    return () => {
      cancelled = true;
    };
  }, [id, reload]);

  const loading = !state || state.id !== id || state.reload !== reload;
  const order = state?.data ?? null;
  const error = loading ? null : state.error;

  const refresh = () => setReload((count) => count + 1);

  const runAction = async () => {
    const action = ACTIONS[confirm];
    setBusy(true);
    try {
      await action.run(order.id);
      toast.success(action.success);
      setConfirm(null);
      refresh();
    } catch (err) {
      toast.error(getApiError(err).message);
      setConfirm(null);
      refresh();   // the order may have changed in the meantime
    } finally {
      setBusy(false);
    }
  };

  const submitDelivery = async (date) => {
    setBusy(true);
    setDeliverError('');
    try {
      await orderService.deliverOrder(order.id, date);
      toast.success('Purchase order marked as delivered.');
      setDelivering(false);
      refresh();
    } catch (err) {
      const apiError = getApiError(err);
      const fieldErrors = mapServerErrors(apiError.errors);
      if (fieldErrors.deliveredDate) {
        setDeliverError(fieldErrors.deliveredDate);   // stay open so the date can be fixed
      } else {
        toast.error(apiError.message);
        setDelivering(false);
        refresh();
      }
    } finally {
      setBusy(false);
    }
  };

  if (error) {
    return (
      <EmptyState
        title={error.status === 404 ? 'Order not found' : 'Could not load the order'}
        message={error.message}
        action={<Link to="/orders" className="btn btn-primary">Back to orders</Link>}
      />
    );
  }

  if (!order) {
    return <Loader text="Loading order..." />;
  }

  const permissions = order.permissions;
  const active = confirm ? ACTIONS[confirm] : null;

  // "Delivered 2 day(s) late", "3 day(s) overdue" and so on
  let timing = null;
  if (order.deliveredDate) {
    const late = daysBetween(order.promisedDeliveryDate, order.deliveredDate);
    if (late > 0) timing = { text: `Delivered ${late} day(s) late`, cls: 'text-danger' };
    else if (late === 0) timing = { text: 'Delivered on time', cls: 'text-success' };
    else timing = { text: `Delivered ${-late} day(s) early`, cls: 'text-success' };
  } else if (order.isOverdue) {
    timing = { text: `${daysBetween(order.promisedDeliveryDate, utcToday())} day(s) overdue`, cls: 'text-danger' };
  }

  const difference = order.totalAmount - order.requestEstimatedTotal;

  return (
    <div style={{ opacity: loading ? 0.6 : 1 }}>
      <div className="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">
        <div>
          <h2 className="h4 mb-1">
            {order.poNumber} <OrderStatusBadge status={order.status} overdue={order.isOverdue} />
          </h2>
          <div className="text-muted">
            For request <Link to={`/requests/${order.purchaseRequestId}`}>{order.requestNumber}</Link> - {order.requestTitle}
          </div>
        </div>
        <div className="d-flex flex-wrap gap-2">
          <Link to="/orders" className="btn btn-outline-secondary">Back</Link>
          {permissions.canSend && (
            <button type="button" className="btn btn-primary" onClick={() => setConfirm('send')}>Mark as sent</button>
          )}
          {permissions.canDeliver && (
            <button
              type="button"
              className="btn btn-success"
              onClick={() => {
                setDeliverError('');
                setDelivering(true);
              }}
            >
              Mark as delivered
            </button>
          )}
          {permissions.canCancel && (
            <button type="button" className="btn btn-outline-danger" onClick={() => setConfirm('cancel')}>Cancel order</button>
          )}
        </div>
      </div>

      <div className="card card-body mb-3">
        <div className="row g-3">
          <div className="col-6 col-md-3">
            <div className="small text-muted">Vendor</div>
            <div>{order.vendorName} <span className="text-muted small">{order.vendorCode}</span></div>
          </div>
          <div className="col-6 col-md-3">
            <div className="small text-muted">Ordered</div>
            <div>{formatDateOnly(order.orderDate)}</div>
          </div>
          <div className="col-6 col-md-3">
            <div className="small text-muted">Promised delivery</div>
            <div>{formatDateOnly(order.promisedDeliveryDate)}</div>
          </div>
          <div className="col-6 col-md-3">
            <div className="small text-muted">Delivered</div>
            <div>{order.deliveredDate ? formatDateOnly(order.deliveredDate) : '-'}</div>
          </div>
          {timing && (
            <div className="col-12">
              <span className={`fw-semibold ${timing.cls}`}>{timing.text}</span>
            </div>
          )}
        </div>
      </div>

      <div className="card mb-3">
        <div className="card-header">Items ordered</div>
        <div className="table-responsive">
          <table className="table align-middle mb-0">
            <thead className="table-light">
              <tr>
                <th>SKU</th>
                <th>Product</th>
                <th className="text-end">Quantity</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map((item) => (
                <tr key={item.productSku + item.productName}>
                  <td>{item.productSku}</td>
                  <td>{item.productName}</td>
                  <td className="text-end">{item.quantity} {item.unit}</td>
                  <td>{item.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <div className="card-header">Price</div>
        <div className="card-body">
          <div className="d-flex justify-content-between">
            <span className="text-muted">Estimated in the request (standard prices)</span>
            <span>{formatMoney(order.requestEstimatedTotal)}</span>
          </div>
          <div className="d-flex justify-content-between fw-semibold">
            <span>Order total (vendor prices)</span>
            <span>{formatMoney(order.totalAmount)}</span>
          </div>
          <div className={`text-end small ${difference < 0 ? 'text-success' : difference > 0 ? 'text-danger' : 'text-muted'}`}>
            {difference < 0 && `${formatMoney(-difference)} below the estimate`}
            {difference > 0 && `${formatMoney(difference)} above the estimate`}
            {difference === 0 && 'Same as the estimate'}
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={Boolean(active)}
        title={active?.title ?? ''}
        message={active?.message ?? ''}
        confirmText={active?.confirmText}
        danger={active?.danger}
        busy={busy}
        onConfirm={runAction}
        onCancel={() => setConfirm(null)}
      />

      {delivering && (
        <DeliverDialog
          orderDate={order.orderDate}
          busy={busy}
          serverError={deliverError}
          onSubmit={submitDelivery}
          onCancel={() => setDelivering(false)}
        />
      )}
    </div>
  );
}
