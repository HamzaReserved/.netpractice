import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import EmptyState from '../../components/common/EmptyState';
import Loader from '../../components/common/Loader';
import Pagination from '../../components/common/Pagination';
import SortHeader from '../../components/common/SortHeader';
import OrderStatusBadge from '../../components/orders/OrderStatusBadge';
import usePagedList from '../../hooks/usePagedList';
import * as orderService from '../../services/orderService';
import { formatDateOnly, formatMoney } from '../../utils/format';
import { ORDER_STATUSES } from '../../utils/orderStatus';

export default function OrdersPage() {
  const navigate = useNavigate();

  const [status, setStatus] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');

  const list = usePagedList(orderService.getOrders, {
    filters: {
      status: status || undefined,
      from: from || undefined,
      to: to || undefined,
    },
    defaultSort: { by: 'orderdate', descending: true },
  });
  const { data, loading, error, sort } = list;
  const filtered = list.hasSearch || status !== '' || from !== '' || to !== '';

  const clearFilters = () => {
    list.changeSearch('');
    setStatus('');
    setFrom('');
    setTo('');
  };

  return (
    <div>
      <h2 className="h4 mb-1">Purchase Orders</h2>
      <p className="text-muted small mb-3">
        Orders are created from approved requests, on the request page, by a Procurement Officer.
      </p>

      <div className="card card-body mb-3">
        <div className="row g-2">
          <div className="col-12 col-md-4">
            <input
              type="search"
              className="form-control"
              placeholder="Search by PO, request, title or vendor..."
              value={list.searchText}
              onChange={(event) => list.changeSearch(event.target.value)}
            />
          </div>
          <div className="col-12 col-md-3">
            <select
              className="form-select"
              value={status}
              onChange={(event) => {
                setStatus(event.target.value);
                list.goToFirstPage();
              }}
            >
              <option value="">All statuses</option>
              {ORDER_STATUSES.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>
          <div className="col-6 col-md-2">
            <input
              type="date"
              className="form-control"
              aria-label="Ordered from"
              title="Ordered from"
              value={from}
              onChange={(event) => {
                setFrom(event.target.value);
                list.goToFirstPage();
              }}
            />
          </div>
          <div className="col-6 col-md-2">
            <input
              type="date"
              className="form-control"
              aria-label="Ordered to"
              title="Ordered to"
              value={to}
              onChange={(event) => {
                setTo(event.target.value);
                list.goToFirstPage();
              }}
            />
          </div>
          <div className="col-12 col-md-1 d-grid">
            <button type="button" className="btn btn-outline-secondary" onClick={clearFilters} disabled={!filtered}>
              Clear
            </button>
          </div>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger d-flex justify-content-between align-items-center">
          <span>{error}</span>
          <button type="button" className="btn btn-sm btn-outline-danger" onClick={list.reload}>
            Retry
          </button>
        </div>
      )}

      {loading && !data && <Loader text="Loading orders..." />}

      {data && data.items.length === 0 && (
        <EmptyState
          title="No purchase orders found"
          message={filtered ? 'No order matches your search or filters.' : 'No purchase order has been created yet.'}
        />
      )}

      {data && data.items.length > 0 && (
        <div style={{ opacity: loading ? 0.5 : 1 }}>
          {/* Desktop and tablet: table */}
          <div className="card d-none d-md-block">
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <SortHeader label="PO" column="number" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Request" column="request" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Vendor" column="vendor" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Status" column="status" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Amount" column="amount" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Ordered" column="orderdate" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Promised" column="promised" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Delivered" column="delivered" sort={sort} onSort={list.toggleSort} />
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((order) => (
                    <tr key={order.id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/orders/${order.id}`)}>
                      <td className="text-nowrap">
                        <Link to={`/orders/${order.id}`} onClick={(event) => event.stopPropagation()}>
                          {order.poNumber}
                        </Link>
                      </td>
                      <td className="text-nowrap">
                        <Link to={`/requests/${order.purchaseRequestId}`} onClick={(event) => event.stopPropagation()}>
                          {order.requestNumber}
                        </Link>
                      </td>
                      <td>{order.vendorName}</td>
                      <td className="text-nowrap"><OrderStatusBadge status={order.status} overdue={order.isOverdue} /></td>
                      <td className="text-end">{formatMoney(order.totalAmount)}</td>
                      <td>{formatDateOnly(order.orderDate)}</td>
                      <td>{formatDateOnly(order.promisedDeliveryDate)}</td>
                      <td>{formatDateOnly(order.deliveredDate)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Phones: one card per order */}
          <div className="d-md-none d-flex flex-column gap-2">
            {data.items.map((order) => (
              <Link key={order.id} to={`/orders/${order.id}`} className="card text-decoration-none text-body">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-start">
                    <div>
                      <div className="fw-semibold">{order.poNumber}</div>
                      <div>{order.vendorName}</div>
                    </div>
                    <div className="text-end">
                      <OrderStatusBadge status={order.status} overdue={order.isOverdue} />
                    </div>
                  </div>
                  <div className="small text-muted mt-2">
                    {order.requestNumber} | promised {formatDateOnly(order.promisedDeliveryDate)}
                  </div>
                  <div className="fw-semibold mt-1">{formatMoney(order.totalAmount)}</div>
                </div>
              </Link>
            ))}
          </div>

          <Pagination
            page={data.page}
            totalPages={data.totalPages}
            totalCount={data.totalCount}
            pageSize={data.pageSize}
            onChange={list.setPage}
          />
        </div>
      )}
    </div>
  );
}
