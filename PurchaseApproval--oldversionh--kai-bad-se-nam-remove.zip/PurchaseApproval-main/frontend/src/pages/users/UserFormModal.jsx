import { useState } from 'react';
import toast from 'react-hot-toast';
import FormField from '../../components/common/FormField';
import { getApiError } from '../../services/api';
import * as userService from '../../services/userService';
import { mapServerErrors } from '../../utils/forms';
import { ROLE_IDS, ROLE_LABELS, ROLES } from '../../utils/roles';

const PASSWORD_PATTERN = /^(?=.*[A-Za-z])(?=.*\d).{8,100}$/;
const PASSWORD_MESSAGE = 'Password must be 8 to 100 characters and contain at least one letter and one number.';

export default function UserFormModal({ user, currentUser, onClose, onSaved }) {
  const isEdit = Boolean(user);
  const isCurrentAdmin = isEdit && user.id === currentUser.id;
  const [form, setForm] = useState(() =>
    user
      ? {
          fullName: user.fullName,
          email: user.email,
          roleId: user.roleId,
          isActive: user.isActive,
          password: '',
        }
      : {
          fullName: '',
          email: '',
          roleId: ROLE_IDS[ROLES.REQUESTER],
          isActive: true,
          password: '',
        }
  );
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }));
  };

  const validate = () => {
    const found = {};
    if (!form.fullName.trim()) found.fullName = 'Full name is required.';
    else if (form.fullName.trim().length > 150) found.fullName = 'Full name can be at most 150 characters.';

    if (!form.email.trim()) found.email = 'Email is required.';
    else if (!/^\S+@\S+\.\S+$/.test(form.email.trim())) found.email = 'Enter a valid email address.';
    else if (form.email.trim().length > 150) found.email = 'Email can be at most 150 characters.';

    if (!isEdit && !PASSWORD_PATTERN.test(form.password)) found.password = PASSWORD_MESSAGE;
    return found;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const found = validate();
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSaving(true);
    try {
      const payload = {
        fullName: form.fullName.trim(),
        email: form.email.trim(),
        roleId: isCurrentAdmin ? ROLE_IDS[ROLES.ADMIN] : Number(form.roleId),
        isActive: isCurrentAdmin ? true : form.isActive,
      };
      if (isEdit) {
        await userService.updateUser(user.id, payload);
      } else {
        await userService.createUser({ ...payload, password: form.password });
      }
      toast.success(isEdit ? 'User updated.' : 'User created.');
      onSaved();
    } catch (error) {
      const apiError = getApiError(error);
      const serverErrors = mapServerErrors(apiError.errors);
      setErrors(serverErrors);
      toast.error(Object.keys(serverErrors).length > 0 ? 'Please fix the highlighted fields.' : apiError.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="modal d-block" tabIndex={-1} role="dialog" aria-modal="true">
        <div className="modal-dialog modal-dialog-centered">
          <form className="modal-content" onSubmit={handleSubmit} noValidate>
            <div className="modal-header">
              <h5 className="modal-title">{isEdit ? 'Edit user' : 'Create user'}</h5>
              <button type="button" className="btn-close" aria-label="Close" onClick={onClose} disabled={saving} />
            </div>

            <div className="modal-body">
              <FormField
                label="Full name"
                name="fullName"
                value={form.fullName}
                onChange={handleChange}
                error={errors.fullName}
                required
                maxLength={150}
              />
              <FormField
                label="Email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                error={errors.email}
                required
                maxLength={150}
              />
              <div className="mb-3">
                <label htmlFor="field-role" className="form-label">
                  Role <span className="text-danger">*</span>
                </label>
                <select
                  id="field-role"
                  name="roleId"
                  className={`form-select${errors.roleId ? ' is-invalid' : ''}`}
                  value={form.roleId}
                  onChange={handleChange}
                  disabled={isCurrentAdmin || saving}
                >
                  {Object.values(ROLES).map((role) => (
                    <option key={role} value={ROLE_IDS[role]}>
                      {ROLE_LABELS[role]}
                    </option>
                  ))}
                </select>
                {errors.roleId && <div className="invalid-feedback">{errors.roleId}</div>}
              </div>

              {!isEdit && (
                <FormField
                  label="Password"
                  name="password"
                  type="password"
                  value={form.password}
                  onChange={handleChange}
                  error={errors.password}
                  required
                  autoComplete="new-password"
                />
              )}

              <div className="form-check form-switch">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="field-isActive"
                  name="isActive"
                  checked={form.isActive}
                  onChange={handleChange}
                  disabled={isCurrentAdmin || saving}
                />
                <label className="form-check-label" htmlFor="field-isActive">
                  Active
                </label>
              </div>
              {isCurrentAdmin && (
                <div className="form-text">You cannot remove your own Admin role or deactivate your account.</div>
              )}
            </div>

            <div className="modal-footer">
              <button type="button" className="btn btn-outline-secondary" onClick={onClose} disabled={saving}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </form>
        </div>
      </div>
      <div className="modal-backdrop show" />
    </>
  );
}
