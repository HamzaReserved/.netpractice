import { useState } from 'react';
import toast from 'react-hot-toast';
import FormField from '../../components/common/FormField';
import { getApiError } from '../../services/api';
import * as userService from '../../services/userService';
import { mapServerErrors } from '../../utils/forms';

const PASSWORD_PATTERN = /^(?=.*[A-Za-z])(?=.*\d).{8,100}$/;
const PASSWORD_MESSAGE = 'Password must be 8 to 100 characters and contain at least one letter and one number.';

export default function ResetUserPasswordModal({ user, onClose, onSaved }) {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const found = {};
    if (!PASSWORD_PATTERN.test(newPassword)) found.newPassword = PASSWORD_MESSAGE;
    if (!confirmPassword) found.confirmPassword = 'Please confirm the new password.';
    else if (newPassword !== confirmPassword) found.confirmPassword = 'Passwords do not match.';
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSaving(true);
    try {
      await userService.resetUserPassword(user.id, newPassword);
      toast.success(`Password reset for ${user.fullName}.`);
      onSaved();
    } catch (error) {
      const apiError = getApiError(error);
      const serverErrors = mapServerErrors(apiError.errors);
      setErrors(serverErrors);
      toast.error(Object.keys(serverErrors).length > 0 ? 'Please fix the highlighted fields.' : apiError.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="modal d-block" tabIndex={-1} role="dialog" aria-modal="true">
        <div className="modal-dialog modal-dialog-centered">
          <form className="modal-content" onSubmit={handleSubmit} noValidate>
            <div className="modal-header">
              <h5 className="modal-title">Reset password</h5>
              <button type="button" className="btn-close" aria-label="Close" onClick={onClose} disabled={saving} />
            </div>
            <div className="modal-body">
              <p className="text-muted">Set a new password for {user.fullName}.</p>
              <FormField
                label="New password"
                name="newPassword"
                type="password"
                value={newPassword}
                onChange={(event) => setNewPassword(event.target.value)}
                error={errors.newPassword}
                required
                autoComplete="new-password"
              />
              <FormField
                label="Confirm new password"
                name="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                error={errors.confirmPassword}
                required
                autoComplete="new-password"
              />
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-outline-secondary" onClick={onClose} disabled={saving}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? 'Resetting...' : 'Reset password'}
              </button>
            </div>
          </form>
        </div>
      </div>
      <div className="modal-backdrop show" />
    </>
  );
}
