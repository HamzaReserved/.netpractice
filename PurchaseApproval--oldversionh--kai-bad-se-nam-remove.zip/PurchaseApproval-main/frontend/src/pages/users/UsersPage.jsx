import { useEffect, useMemo, useState } from 'react';
import toast from 'react-hot-toast';
import ConfirmDialog from '../../components/common/ConfirmDialog';
import EmptyState from '../../components/common/EmptyState';
import Loader from '../../components/common/Loader';
import Pagination from '../../components/common/Pagination';
import SortHeader from '../../components/common/SortHeader';
import { useAuth } from '../../context/useAuth';
import useDebounce from '../../hooks/useDebounce';
import { getApiError } from '../../services/api';
import * as userService from '../../services/userService';
import { formatDate } from '../../utils/format';
import { ROLE_LABELS, ROLES } from '../../utils/roles';
import ResetUserPasswordModal from './ResetUserPasswordModal';
import UserFormModal from './UserFormModal';

const PAGE_SIZE = 10;
const USER_ROLES = Object.values(ROLES);

function StatusBadge({ active }) {
  return (
    <span className={`badge ${active ? 'text-bg-success' : 'text-bg-secondary'}`}>
      {active ? 'Active' : 'Inactive'}
    </span>
  );
}

export default function UsersPage() {
  const { user: currentUser } = useAuth();
  const [searchText, setSearchText] = useState('');
  const search = useDebounce(searchText, 400);
  const [role, setRole] = useState('');
  const [status, setStatus] = useState('all');
  const [sort, setSort] = useState({ by: 'name', descending: false });
  const [page, setPage] = useState(1);
  const [reload, setReload] = useState(0);
  const [result, setResult] = useState(null);
  const [formUser, setFormUser] = useState(undefined);
  const [passwordUser, setPasswordUser] = useState(null);
  const [statusUser, setStatusUser] = useState(null);
  const [statusBusy, setStatusBusy] = useState(false);

  const params = useMemo(
    () => ({
      page,
      pageSize: PAGE_SIZE,
      search: search.trim() || undefined,
      role: role || undefined,
      isActive: status === 'all' ? undefined : status === 'active',
      sortBy: sort.by,
      descending: sort.descending,
    }),
    [page, search, role, status, sort]
  );

  useEffect(() => {
    let cancelled = false;
    userService
      .getUsers(params)
      .then((data) => {
        if (!cancelled) setResult({ params, reload, data, error: null });
      })
      .catch((error) => {
        if (!cancelled) setResult({ params, reload, data: null, error: getApiError(error).message });
      });
    return () => {
      cancelled = true;
    };
  }, [params, reload]);

  const loading = !result || result.params !== params || result.reload !== reload;
  const data = result?.data ?? null;
  const error = loading ? null : result.error;
  const filtered = Boolean(search.trim()) || Boolean(role) || status !== 'all';

  const handleSort = (column) => {
    setSort((current) =>
      current.by === column
        ? { by: column, descending: !current.descending }
        : { by: column, descending: false }
    );
    setPage(1);
  };

  const handleSaved = () => {
    setFormUser(undefined);
    setPasswordUser(null);
    setReload((count) => count + 1);
  };

  const confirmStatusChange = async () => {
    if (!statusUser) return;
    setStatusBusy(true);
    try {
      const isActive = !statusUser.isActive;
      await userService.updateUser(statusUser.id, {
        fullName: statusUser.fullName,
        email: statusUser.email,
        roleId: statusUser.roleId,
        isActive,
      });
      toast.success(`${statusUser.fullName} ${isActive ? 'activated' : 'deactivated'}.`);
      setStatusUser(null);
      setReload((count) => count + 1);
    } catch (error) {
      toast.error(getApiError(error).message);
      setStatusUser(null);
    } finally {
      setStatusBusy(false);
    }
  };

  const addButton = (
    <button type="button" className="btn btn-primary" onClick={() => setFormUser(null)}>
      Create user
    </button>
  );

  return (
    <div>
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h2 className="h4 mb-0">Users</h2>
        {addButton}
      </div>

      <div className="card card-body mb-3">
        <div className="row g-2">
          <div className="col-12 col-lg-6">
            <input
              type="search"
              className="form-control"
              placeholder="Search by name or email..."
              value={searchText}
              onChange={(event) => {
                setSearchText(event.target.value);
                setPage(1);
              }}
            />
          </div>
          <div className="col-12 col-sm-6 col-lg-3">
            <select
              className="form-select"
              aria-label="Filter by role"
              value={role}
              onChange={(event) => {
                setRole(event.target.value);
                setPage(1);
              }}
            >
              <option value="">All roles</option>
              {USER_ROLES.map((item) => (
                <option key={item} value={item}>
                  {ROLE_LABELS[item]}
                </option>
              ))}
            </select>
          </div>
          <div className="col-12 col-sm-6 col-lg-3">
            <select
              className="form-select"
              aria-label="Filter by status"
              value={status}
              onChange={(event) => {
                setStatus(event.target.value);
                setPage(1);
              }}
            >
              <option value="all">All statuses</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger d-flex justify-content-between align-items-center">
          <span>{error}</span>
          <button type="button" className="btn btn-sm btn-outline-danger" onClick={() => setReload((count) => count + 1)}>
            Retry
          </button>
        </div>
      )}

      {loading && !data && <Loader text="Loading users..." />}

      {data && data.items.length === 0 && (
        <EmptyState
          title="No users found"
          message={filtered ? 'No user matches your search or filters.' : 'No users have been added yet.'}
          action={filtered ? null : addButton}
        />
      )}

      {data && data.items.length > 0 && (
        <div style={{ opacity: loading ? 0.5 : 1 }}>
          <div className="card d-none d-md-block">
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <SortHeader label="Name" column="name" sort={sort} onSort={handleSort} />
                    <SortHeader label="Email" column="email" sort={sort} onSort={handleSort} />
                    <SortHeader label="Role" column="role" sort={sort} onSort={handleSort} />
                    <SortHeader label="Status" column="status" sort={sort} onSort={handleSort} />
                    <SortHeader label="Created" column="created" sort={sort} onSort={handleSort} />
                    <th scope="col" className="text-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((item) => {
                    const isCurrentUser = item.id === currentUser.id;
                    return (
                      <tr key={item.id}>
                        <td>{item.fullName}</td>
                        <td>{item.email}</td>
                        <td>{ROLE_LABELS[item.role] || item.role}</td>
                        <td><StatusBadge active={item.isActive} /></td>
                        <td>{formatDate(item.createdAt)}</td>
                        <td className="text-end text-nowrap">
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-primary me-2"
                            onClick={() => setFormUser(item)}
                          >
                            Edit
                          </button>
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-secondary me-2"
                            onClick={() => setPasswordUser(item)}
                          >
                            Reset password
                          </button>
                          <button
                            type="button"
                            className={`btn btn-sm ${item.isActive ? 'btn-outline-danger' : 'btn-outline-success'}`}
                            onClick={() => setStatusUser(item)}
                            disabled={isCurrentUser}
                            title={isCurrentUser ? 'You cannot deactivate your own account.' : undefined}
                          >
                            {item.isActive ? 'Deactivate' : 'Activate'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div className="d-md-none d-flex flex-column gap-2">
            {data.items.map((item) => {
              const isCurrentUser = item.id === currentUser.id;
              return (
                <div className="card" key={item.id}>
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-start gap-2">
                      <div>
                        <div className="fw-semibold">{item.fullName}</div>
                        <div className="small text-muted">{item.email}</div>
                      </div>
                      <StatusBadge active={item.isActive} />
                    </div>
                    <div className="small mt-2">
                      {ROLE_LABELS[item.role] || item.role} · Created {formatDate(item.createdAt)}
                    </div>
                    <div className="d-flex flex-wrap gap-2 mt-3">
                      <button type="button" className="btn btn-sm btn-outline-primary" onClick={() => setFormUser(item)}>
                        Edit
                      </button>
                      <button type="button" className="btn btn-sm btn-outline-secondary" onClick={() => setPasswordUser(item)}>
                        Reset password
                      </button>
                      <button
                        type="button"
                        className={`btn btn-sm ${item.isActive ? 'btn-outline-danger' : 'btn-outline-success'}`}
                        onClick={() => setStatusUser(item)}
                        disabled={isCurrentUser}
                        title={isCurrentUser ? 'You cannot deactivate your own account.' : undefined}
                      >
                        {item.isActive ? 'Deactivate' : 'Activate'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <Pagination
            page={data.page}
            totalPages={data.totalPages}
            totalCount={data.totalCount}
            pageSize={data.pageSize}
            onChange={setPage}
          />
        </div>
      )}

      {formUser !== undefined && (
        <UserFormModal
          key={formUser?.id ?? 'new'}
          user={formUser}
          currentUser={currentUser}
          onClose={() => setFormUser(undefined)}
          onSaved={handleSaved}
        />
      )}
      {passwordUser && (
        <ResetUserPasswordModal
          user={passwordUser}
          onClose={() => setPasswordUser(null)}
          onSaved={handleSaved}
        />
      )}
      <ConfirmDialog
        open={Boolean(statusUser)}
        title={statusUser?.isActive ? 'Deactivate user' : 'Activate user'}
        message={
          statusUser
            ? `${statusUser.isActive ? 'Deactivate' : 'Activate'} ${statusUser.fullName}?`
            : ''
        }
        confirmText={statusUser?.isActive ? 'Deactivate' : 'Activate'}
        danger={Boolean(statusUser?.isActive)}
        busy={statusBusy}
        onConfirm={confirmStatusChange}
        onCancel={() => setStatusUser(null)}
      />
    </div>
  );
}
