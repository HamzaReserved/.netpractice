import { Link, useNavigate } from 'react-router-dom';
import EmptyState from '../../components/common/EmptyState';
import Loader from '../../components/common/Loader';
import Pagination from '../../components/common/Pagination';
import SortHeader from '../../components/common/SortHeader';
import usePagedList from '../../hooks/usePagedList';
import * as requestService from '../../services/requestService';
import { formatDateOnly, formatDateTime, formatMoney } from '../../utils/format';

export default function ApprovalsPage() {
  const navigate = useNavigate();

  // The same list as "Purchase Requests", filtered to what waits for this person's decision
  const list = usePagedList(requestService.getRequests, {
    filters: { awaitingMyApproval: true },
    defaultSort: { by: 'submitted', descending: false },   // oldest first
  });
  const { data, loading, error, sort } = list;

  return (
    <div>
      <h2 className="h4 mb-1">Approvals</h2>
      <p className="text-muted small mb-3">
        Submitted requests waiting for a decision.
      </p>

      <div className="card card-body mb-3">
        <input
          type="search"
          className="form-control"
          placeholder="Search by number, title or requester..."
          value={list.searchText}
          onChange={(event) => list.changeSearch(event.target.value)}
        />
      </div>

      {error && (
        <div className="alert alert-danger d-flex justify-content-between align-items-center">
          <span>{error}</span>
          <button type="button" className="btn btn-sm btn-outline-danger" onClick={list.reload}>
            Retry
          </button>
        </div>
      )}

      {loading && !data && <Loader text="Loading approvals..." />}

      {data && data.items.length === 0 && (
        <EmptyState
          title="Nothing is waiting for you"
          message={list.hasSearch ? 'No waiting request matches your search.' : 'All submitted requests have been decided.'}
        />
      )}

      {data && data.items.length > 0 && (
        <div style={{ opacity: loading ? 0.5 : 1 }}>
          {/* Desktop and tablet: table */}
          <div className="card d-none d-md-block">
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <SortHeader label="Number" column="number" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Title" column="title" sort={sort} onSort={list.toggleSort} />
                    <th scope="col">Requester</th>
                    <th scope="col" className="text-end">Items</th>
                    <SortHeader label="Amount" column="amount" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Submitted" column="submitted" sort={sort} onSort={list.toggleSort} />
                    <SortHeader label="Required by" column="required" sort={sort} onSort={list.toggleSort} />
                    <th scope="col" className="text-end">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((request) => (
                    <tr key={request.id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/requests/${request.id}`)}>
                      <td className="text-nowrap">{request.requestNumber}</td>
                      <td>{request.title}</td>
                      <td>{request.requesterName}</td>
                      <td className="text-end">{request.itemCount}</td>
                      <td className="text-end">{formatMoney(request.totalAmount)}</td>
                      <td>{formatDateTime(request.submittedAt)}</td>
                      <td>{formatDateOnly(request.requiredByDate)}</td>
                      <td className="text-end">
                        <Link to={`/requests/${request.id}`} className="btn btn-sm btn-primary" onClick={(event) => event.stopPropagation()}>
                          Review
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Phones: one card per request */}
          <div className="d-md-none d-flex flex-column gap-2">
            {data.items.map((request) => (
              <Link key={request.id} to={`/requests/${request.id}`} className="card text-decoration-none text-body">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-start">
                    <div>
                      <div className="fw-semibold">{request.requestNumber}</div>
                      <div>{request.title}</div>
                    </div>
                    <span className="badge text-bg-primary">Review</span>
                  </div>
                  <div className="small text-muted mt-2">
                    {request.requesterName} | {request.itemCount} item(s) | submitted {formatDateTime(request.submittedAt)}
                  </div>
                  <div className="fw-semibold mt-1">{formatMoney(request.totalAmount)}</div>
                </div>
              </Link>
            ))}
          </div>

          <Pagination
            page={data.page}
            totalPages={data.totalPages}
            totalCount={data.totalCount}
            pageSize={data.pageSize}
            onChange={list.setPage}
          />
        </div>
      )}
    </div>
  );
}
