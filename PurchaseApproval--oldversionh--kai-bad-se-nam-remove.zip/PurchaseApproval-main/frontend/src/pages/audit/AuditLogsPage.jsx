import { useEffect, useMemo, useState } from 'react';
import EmptyState from '../../components/common/EmptyState';
import Loader from '../../components/common/Loader';
import Pagination from '../../components/common/Pagination';
import SortHeader from '../../components/common/SortHeader';
import useDebounce from '../../hooks/useDebounce';
import * as auditService from '../../services/auditService';
import { getApiError } from '../../services/api';
import { formatDateTime } from '../../utils/format';

const PAGE_SIZE = 10;

function formatJsonValue(value) {
  if (!value) return '—';
  try {
    const parsed = JSON.parse(value);
    return JSON.stringify(parsed, null, 2);
  } catch {
    return value;
  }
}

export default function AuditLogsPage() {
  const [searchText, setSearchText] = useState('');
  const search = useDebounce(searchText, 400);
  const [entity, setEntity] = useState('');
  const [action, setAction] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [filters, setFilters] = useState({ entities: [], actions: [] });
  const [sort, setSort] = useState({ by: 'time', descending: true });
  const [page, setPage] = useState(1);
  const [reload, setReload] = useState(0);
  const [result, setResult] = useState(null);

  useEffect(() => {
    let cancelled = false;
    auditService
      .getAuditFilters()
      .then((data) => {
        if (!cancelled) setFilters({ entities: data.entities || [], actions: data.actions || [] });
      })
      .catch(() => {
        if (!cancelled) setFilters({ entities: [], actions: [] });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const params = useMemo(
    () => ({
      page,
      pageSize: PAGE_SIZE,
      search: search.trim() || undefined,
      entityName: entity || undefined,
      action: action || undefined,
      from: from || undefined,
      to: to || undefined,
      sortBy: sort.by,
      descending: sort.descending,
    }),
    [action, entity, from, page, search, sort, to]
  );

  useEffect(() => {
    let cancelled = false;
    auditService
      .getAuditLogs(params)
      .then((data) => {
        if (!cancelled) setResult({ params, reload, data, error: null });
      })
      .catch((error) => {
        if (!cancelled) setResult({ params, reload, data: null, error: getApiError(error).message });
      });
    return () => {
      cancelled = true;
    };
  }, [params, reload]);

  const loading = !result || result.params !== params || result.reload !== reload;
  const data = result?.data ?? null;
  const error = loading ? null : result.error;
  const filtered = Boolean(search.trim()) || Boolean(entity) || Boolean(action) || Boolean(from) || Boolean(to);

  const clearFilters = () => {
    setSearchText('');
    setEntity('');
    setAction('');
    setFrom('');
    setTo('');
    setPage(1);
  };

  const handleSort = (column) => {
    setSort((current) =>
      current.by === column
        ? { by: column, descending: !current.descending }
        : { by: column, descending: false }
    );
    setPage(1);
  };

  return (
    <div>
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h2 className="h4 mb-0">Audit log</h2>
      </div>

      <div className="card card-body mb-3">
        <div className="row g-2">
          <div className="col-12 col-lg-4">
            <input
              type="search"
              className="form-control"
              placeholder="Search by entity, action or values..."
              value={searchText}
              onChange={(event) => {
                setSearchText(event.target.value);
                setPage(1);
              }}
            />
          </div>
          <div className="col-12 col-sm-6 col-lg-2">
            <select
              className="form-select"
              value={entity}
              onChange={(event) => {
                setEntity(event.target.value);
                setPage(1);
              }}
            >
              <option value="">All entities</option>
              {filters.entities.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
          <div className="col-12 col-sm-6 col-lg-2">
            <select
              className="form-select"
              value={action}
              onChange={(event) => {
                setAction(event.target.value);
                setPage(1);
              }}
            >
              <option value="">All actions</option>
              {filters.actions.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
          <div className="col-6 col-lg-2">
            <input
              type="date"
              className="form-control"
              value={from}
              onChange={(event) => {
                setFrom(event.target.value);
                setPage(1);
              }}
            />
          </div>
          <div className="col-6 col-lg-2">
            <input
              type="date"
              className="form-control"
              value={to}
              onChange={(event) => {
                setTo(event.target.value);
                setPage(1);
              }}
            />
          </div>
          <div className="col-12 d-grid">
            <button type="button" className="btn btn-outline-secondary" onClick={clearFilters} disabled={!filtered}>
              Clear filters
            </button>
          </div>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger d-flex justify-content-between align-items-center">
          <span>{error}</span>
          <button type="button" className="btn btn-sm btn-outline-danger" onClick={() => setReload((count) => count + 1)}>
            Retry
          </button>
        </div>
      )}

      {loading && !data && <Loader text="Loading audit log..." />}

      {data && data.items.length === 0 && (
        <EmptyState
          title="No audit entries found"
          message={filtered ? 'No audit entries match your search or filters.' : 'No actions have been logged yet.'}
        />
      )}

      {data && data.items.length > 0 && (
        <div style={{ opacity: loading ? 0.5 : 1 }}>
          <div className="card d-none d-md-block">
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <SortHeader label="Time" column="time" sort={sort} onSort={handleSort} />
                    <th scope="col">User</th>
                    <SortHeader label="Action" column="action" sort={sort} onSort={handleSort} />
                    <SortHeader label="Entity" column="entity" sort={sort} onSort={handleSort} />
                    <th scope="col">Entity ID</th>
                    <th scope="col">Old values</th>
                    <th scope="col">New values</th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((item) => (
                    <tr key={item.id}>
                      <td className="text-nowrap">{formatDateTime(item.timestamp)}</td>
                      <td>{item.userName || '(not logged in)'}</td>
                      <td>{item.action}</td>
                      <td>{item.entityName}</td>
                      <td>{item.entityId ?? '—'}</td>
                      <td>
                        <pre className="mb-0 small text-muted" style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                          {formatJsonValue(item.oldValues)}
                        </pre>
                      </td>
                      <td>
                        <pre className="mb-0 small text-muted" style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                          {formatJsonValue(item.newValues)}
                        </pre>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="d-md-none d-flex flex-column gap-2">
            {data.items.map((item) => (
              <div className="card" key={item.id}>
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-start gap-2">
                    <div>
                      <div className="fw-semibold">{item.action}</div>
                      <div className="small text-muted">{item.entityName}</div>
                    </div>
                    <div className="small text-muted text-nowrap">{formatDateTime(item.timestamp)}</div>
                  </div>
                  <div className="small mt-2">User: {item.userName || '(not logged in)'}</div>
                  {item.entityId && <div className="small">Entity ID: {item.entityId}</div>}
                  {item.oldValues && (
                    <div className="mt-2">
                      <div className="small text-uppercase text-muted">Old values</div>
                      <pre className="mb-0 small text-muted" style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                        {formatJsonValue(item.oldValues)}
                      </pre>
                    </div>
                  )}
                  {item.newValues && (
                    <div className="mt-2">
                      <div className="small text-uppercase text-muted">New values</div>
                      <pre className="mb-0 small text-muted" style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                        {formatJsonValue(item.newValues)}
                      </pre>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          <Pagination
            page={data.page}
            totalPages={data.totalPages}
            totalCount={data.totalCount}
            pageSize={data.pageSize}
            onChange={setPage}
          />
        </div>
      )}
    </div>
  );
}
