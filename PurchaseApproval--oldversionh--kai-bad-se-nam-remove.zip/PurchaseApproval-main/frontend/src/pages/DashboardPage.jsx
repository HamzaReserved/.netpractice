import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Loader from '../components/common/Loader';
import MonthlySpendChart from '../components/dashboard/MonthlySpendChart';
import RequestsByStatusChart from '../components/dashboard/RequestsByStatusChart';
import StatCard from '../components/dashboard/StatCard';
import { useAuth } from '../context/useAuth';
import { getApiError } from '../services/api';
import * as dashboardService from '../services/dashboardService';
import { ACCESS, ROLE_LABELS } from '../utils/roles';
import './dashboard.css';

export default function DashboardPage() {
  const { user } = useAuth();
  const canCreate = ACCESS.requestCreate.includes(user.role);

  const [reload, setReload] = useState(0);
  const [state, setState] = useState(null);   // the answer, remembered with the question it answered

  useEffect(() => {
    let cancelled = false;
    dashboardService
      .getSummary()
      .then((data) => {
        if (!cancelled) setState({ reload, data, error: null });
      })
      .catch((err) => {
        if (!cancelled) setState({ reload, data: null, error: getApiError(err).message });
      });
    return () => {
      cancelled = true;
    };
  }, [reload]);

  const loading = !state || state.reload !== reload;
  const data = state?.data ?? null;
  const error = loading ? null : state.error;
  const refresh = () => setReload((count) => count + 1);

  return (
    <div className="dashboard-page">
      <div className="dashboard-heading d-flex flex-wrap justify-content-between align-items-start gap-2 mb-4">
        <div>
          <h2 className="h4 mb-1">Dashboard</h2>
          <div className="text-muted small">
            Welcome, {user.fullName} ({ROLE_LABELS[user.role] || user.role}).
          </div>
        </div>
        <div className="d-flex flex-wrap align-items-center gap-2">
          {canCreate && (
            <Link to="/requests/new" className="btn btn-sm btn-primary">
              New request
            </Link>
          )}
        </div>
      </div>

      {error && (
        <div className="alert alert-danger d-flex justify-content-between align-items-center">
          <span>{error}</span>
          <button type="button" className="btn btn-sm btn-outline-danger" onClick={refresh}>
            Retry
          </button>
        </div>
      )}

      {loading && !data && <Loader text="Loading dashboard..." />}

      {data && (
        <div style={{ opacity: loading ? 0.6 : 1 }}>
          <div className="row g-3 mb-3">
            {data.cards.map((card) => (
              <div className="col-12 col-sm-6 col-xl-3" key={card.key}>
                <StatCard card={card} />
              </div>
            ))}
          </div>

          <div className="row g-3">
            <div className="col-12 col-lg-5">
              <div className="card dashboard-panel h-100">
                <div className="card-header">Requests by status</div>
                <div className="card-body">
                  <RequestsByStatusChart items={data.requestsByStatus} />
                </div>
              </div>
            </div>
            <div className="col-12 col-lg-7">
              <div className="card dashboard-panel h-100">
                <div className="card-header">{data.spendTitle}</div>
                <div className="card-body">
                  <MonthlySpendChart points={data.monthlySpend} />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
