using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;
using PurchaseApproval.Api.Services;
using Xunit;

namespace PurchaseApproval.Tests;

public class UserServiceTests
{
    private sealed record Harness(UserService Service, AppDbContext Db, FakeCurrentUser Current);

    // User 1 is the logged-in admin, user 2 is an ordinary requester
    private static async Task<Harness> CreateAsync()
    {
        var (db, current) = TestDb.Create(1);
        current.Role = Roles.Admin;

        db.Users.AddRange(
            new User { Id = 1, FullName = "Admin", Email = "admin@test.example", PasswordHash = "x", RoleId = (int)UserRole.Admin },
            new User { Id = 2, FullName = "Requester", Email = "req@test.example", PasswordHash = "x", RoleId = (int)UserRole.Requester });
        await db.SaveChangesAsync();

        var service = new UserService(new Repository<User>(db), db, current, new AuditService(db));
        return new Harness(service, db, current);
    }

    private static UserCreateInput NewUser(string email = "new@test.example", string name = "New Person", UserRole role = UserRole.Manager) =>
        new() { FullName = name, Email = email, RoleId = (int)role, Password = "Secret@123" };

    private static UserUpdateInput Edit(string email, UserRole role, bool active = true, string name = "Renamed Person") =>
        new() { FullName = name, Email = email, RoleId = (int)role, IsActive = active };

    [Fact]
    public async Task Create_HashesThePassword_AndNeverShowsItInTheAuditLog()
    {
        var h = await CreateAsync();

        var dto = await h.Service.CreateAsync(NewUser("  new@test.example  "));

        Assert.Equal("new@test.example", dto.Email);
        Assert.Equal((int)UserRole.Manager, dto.RoleId);
        Assert.Equal(UserRole.Manager, dto.Role);

        var entity = await h.Db.Users.SingleAsync(u => u.Id == dto.Id);
        Assert.NotEqual("Secret@123", entity.PasswordHash);
        Assert.Equal(PasswordVerificationResult.Success,
            new PasswordHasher<User>().VerifyHashedPassword(entity, entity.PasswordHash, "Secret@123"));

        var log = await h.Db.AuditLogs.SingleAsync(l => l.Action == "Create" && l.EntityName == "User" && l.EntityId == dto.Id);
        Assert.DoesNotContain("PasswordHash", log.NewValues);
        Assert.DoesNotContain(entity.PasswordHash, log.NewValues);
    }

    [Fact]
    public async Task Create_WithAnUnknownRoleId_IsRefusedWithAFieldError()
    {
        var h = await CreateAsync();
        var input = NewUser();
        input.RoleId = 999;

        var ex = await Assert.ThrowsAsync<AppException>(() => h.Service.CreateAsync(input));

        Assert.True(ex.Errors!.ContainsKey("RoleId"));
    }

    [Fact]
    public async Task Create_WithATakenEmail_IsRefusedWithAFieldError()
    {
        var h = await CreateAsync();

        var ex = await Assert.ThrowsAsync<ConflictException>(() => h.Service.CreateAsync(NewUser("admin@test.example")));

        Assert.True(ex.Errors!.ContainsKey("Email"));
    }

    [Fact]
    public async Task Update_ChangesRoleAndStatus_ButNotToAnEmailThatIsTaken()
    {
        var h = await CreateAsync();

        var updated = await h.Service.UpdateAsync(2, Edit("req@test.example", UserRole.ProcurementOfficer, active: false));

        Assert.Equal(UserRole.ProcurementOfficer, updated.Role);
        Assert.False(updated.IsActive);
        Assert.Equal("Renamed Person", updated.FullName);

        await Assert.ThrowsAsync<ConflictException>(
            () => h.Service.UpdateAsync(2, Edit("admin@test.example", UserRole.Requester)));   // belongs to user 1
    }

    [Fact]
    public async Task AnAdmin_CannotDeactivateOrDemoteTheirOwnAccount()
    {
        var h = await CreateAsync();

        await Assert.ThrowsAsync<ConflictException>(
            () => h.Service.UpdateAsync(1, Edit("admin@test.example", UserRole.Admin, active: false)));
        await Assert.ThrowsAsync<ConflictException>(
            () => h.Service.UpdateAsync(1, Edit("admin@test.example", UserRole.Manager)));

        // Other edits to their own account are fine
        var same = await h.Service.UpdateAsync(1, Edit("admin@test.example", UserRole.Admin, name: "Admin Renamed"));
        Assert.Equal("Admin Renamed", same.FullName);
    }

    [Fact]
    public async Task ADeactivatedUser_ShowsUpInTheInactiveFilter()
    {
        var h = await CreateAsync();
        await h.Service.UpdateAsync(2, Edit("req@test.example", UserRole.Requester, active: false));

        var inactive = await h.Service.GetPagedAsync(new UserQuery { IsActive = false });
        var active = await h.Service.GetPagedAsync(new UserQuery { IsActive = true });

        Assert.Equal(new[] { 2 }, inactive.Items.Select(u => u.Id).ToArray());
        Assert.Equal(1, active.TotalCount);
    }

    [Fact]
    public async Task ResetPassword_ChangesTheHash_AndIsAudited()
    {
        var h = await CreateAsync();

        await h.Service.ResetPasswordAsync(2, "Brand@New9");

        var entity = await h.Db.Users.SingleAsync(u => u.Id == 2);
        Assert.Equal(PasswordVerificationResult.Success,
            new PasswordHasher<User>().VerifyHashedPassword(entity, entity.PasswordHash, "Brand@New9"));

        var log = await h.Db.AuditLogs.SingleAsync(l => l.Action == "PasswordReset");
        Assert.Equal("User", log.EntityName);
        Assert.Equal(2, log.EntityId);
        Assert.Equal(1, log.UserId);   // who did it
        Assert.Null(log.NewValues);    // and never what the password is

        await Assert.ThrowsAsync<NotFoundException>(() => h.Service.ResetPasswordAsync(99, "Brand@New9"));
    }

    [Fact]
    public async Task List_SearchesSortsAndPages()
    {
        var h = await CreateAsync();
        for (var i = 1; i <= 12; i++)
            await h.Service.CreateAsync(NewUser($"alpha{i}@test.example", $"Alpha {i:00}"));

        var page2 = await h.Service.GetPagedAsync(new UserQuery { Search = "Alpha", Page = 2, PageSize = 5 });
        Assert.Equal(12, page2.TotalCount);
        Assert.Equal(5, page2.Items.Count);
        Assert.Equal("Alpha 06", page2.Items[0].FullName);

        var last = await h.Service.GetPagedAsync(new UserQuery { Search = "Alpha", SortBy = "name", Descending = true });
        Assert.Equal("Alpha 12", last.Items[0].FullName);

        var managers = await h.Service.GetPagedAsync(new UserQuery { Role = UserRole.Manager });
        Assert.Equal(12, managers.TotalCount);
    }
}
