using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;
using PurchaseApproval.Api.Services;
using Xunit;

namespace PurchaseApproval.Tests;

public class DashboardServiceTests
{
    private sealed record Harness(DashboardService Service, FakeCurrentUser Current);

    // Users: 1 and 2 requesters, 3 manager, 4 officer, 5 admin.
    // Requests:
    //   user 1: PR-1 draft 100, PR-2 submitted 200, PR-3 approved 300, PR-4 rejected 400,
    //           PR-5 PO created 500, PR-6 cancelled 600
    //   user 2: PR-7 submitted 700, PR-8 draft 800
    //   admin:  PR-9 submitted 900
    // Approvals: PR-3 approved this month, PR-5 approved last month.
    // Orders: PO-1 delivered 450 (this month), PO-2 sent 50 (two months ago, overdue), PO-3 cancelled 999.
    private static async Task<Harness> CreateAsync()
    {
        var (db, current) = TestDb.Create(1);
        var now = DateTime.UtcNow;
        var thisMonth = new DateTime(now.Year, now.Month, 1);

        db.Users.AddRange(
            new User { Id = 1, FullName = "Requester One", Email = "r1@test.example", PasswordHash = "x", RoleId = (int)UserRole.Requester },
            new User { Id = 2, FullName = "Requester Two", Email = "r2@test.example", PasswordHash = "x", RoleId = (int)UserRole.Requester },
            new User { Id = 3, FullName = "Manager", Email = "m@test.example", PasswordHash = "x", RoleId = (int)UserRole.Manager },
            new User { Id = 4, FullName = "Officer", Email = "o@test.example", PasswordHash = "x", RoleId = (int)UserRole.ProcurementOfficer },
            new User { Id = 5, FullName = "Admin", Email = "a@test.example", PasswordHash = "x", RoleId = (int)UserRole.Admin });

        PurchaseRequest Req(string number, int requesterId, RequestStatus status, decimal total) => new()
        {
            RequestNumber = number, Title = number, RequesterId = requesterId,
            Status = status, TotalAmount = total, CreatedAt = now
        };

        var r3 = Req("PR-3", 1, RequestStatus.Approved, 300);
        var r5 = Req("PR-5", 1, RequestStatus.PoCreated, 500);
        db.PurchaseRequests.AddRange(
            Req("PR-1", 1, RequestStatus.Draft, 100),
            Req("PR-2", 1, RequestStatus.Submitted, 200),
            r3,
            Req("PR-4", 1, RequestStatus.Rejected, 400),
            r5,
            Req("PR-6", 1, RequestStatus.Cancelled, 600),
            Req("PR-7", 2, RequestStatus.Submitted, 700),
            Req("PR-8", 2, RequestStatus.Draft, 800),
            Req("PR-9", 5, RequestStatus.Submitted, 900));
        await db.SaveChangesAsync();

        db.Approvals.AddRange(
            new Approval { PurchaseRequestId = r3.Id, ApproverId = 3, Decision = ApprovalDecision.Approved, DecidedAt = now },
            new Approval { PurchaseRequestId = r5.Id, ApproverId = 3, Decision = ApprovalDecision.Approved, DecidedAt = thisMonth.AddDays(-5) });

        db.PurchaseOrders.AddRange(
            new PurchaseOrder
            {
                PoNumber = "PO-1", PurchaseRequestId = r5.Id, VendorId = 1,
                OrderDate = thisMonth, PromisedDeliveryDate = thisMonth.AddDays(5), DeliveredDate = thisMonth.AddDays(4),
                TotalAmount = 450, Status = PurchaseOrderStatus.Delivered
            },
            new PurchaseOrder
            {
                PoNumber = "PO-2", PurchaseRequestId = r5.Id, VendorId = 1,
                OrderDate = thisMonth.AddMonths(-2), PromisedDeliveryDate = thisMonth.AddMonths(-2).AddDays(5),
                TotalAmount = 50, Status = PurchaseOrderStatus.Sent
            },
            new PurchaseOrder
            {
                PoNumber = "PO-3", PurchaseRequestId = r5.Id, VendorId = 1,
                OrderDate = thisMonth, PromisedDeliveryDate = thisMonth.AddDays(5),
                TotalAmount = 999, Status = PurchaseOrderStatus.Cancelled
            });
        await db.SaveChangesAsync();

        var service = new DashboardService(
            new Repository<PurchaseRequest>(db), new Repository<PurchaseOrder>(db),
            new Repository<Approval>(db), current);
        return new Harness(service, current);
    }

    private static async Task<DashboardDto> SummaryAsync(Harness h, int userId, string role)
    {
        h.Current.UserId = userId;
        h.Current.Role = role;
        return await h.Service.GetSummaryAsync();
    }

    private static decimal Value(DashboardDto d, string key) => d.Cards.Single(c => c.Key == key).Value;

    [Fact]
    public async Task Requester_SeesOnlyTheirOwnNumbers()
    {
        var h = await CreateAsync();

        var d = await SummaryAsync(h, 1, Roles.Requester);

        Assert.Equal(new[] { "total", "awaiting", "approvedThisMonth", "needsRevision" }, d.Cards.Select(c => c.Key).ToArray());
        Assert.Equal(6m, Value(d, "total"));               // PR-1 to PR-6
        Assert.Equal(1m, Value(d, "awaiting"));            // PR-2
        Assert.Equal(1m, Value(d, "approvedThisMonth"));   // PR-3 only: PR-5 was approved last month
        Assert.Equal(1m, Value(d, "needsRevision"));       // PR-4
        Assert.Equal(6, d.RequestsByStatus.Sum(s => s.Count));
        Assert.Contains("requested", d.SpendTitle);
        Assert.Equal(1400m, d.MonthlySpend.Last().Amount);   // 200 + 300 + 400 + 500, no draft and no cancelled
        Assert.Equal(4, d.MonthlySpend.Last().Count);
    }

    [Fact]
    public async Task Manager_SeesEverythingSubmitted_ButNotOtherPeoplesDrafts()
    {
        var h = await CreateAsync();

        var d = await SummaryAsync(h, 3, Roles.Manager);

        Assert.Equal(new[] { "total", "pending", "approvedThisMonth", "poValue" }, d.Cards.Select(c => c.Key).ToArray());
        Assert.Equal(7m, Value(d, "total"));               // all except the two drafts
        Assert.Equal(3m, Value(d, "pending"));             // PR-2, PR-7, PR-9
        Assert.Equal(1m, Value(d, "approvedThisMonth"));
        Assert.Equal(500m, Value(d, "poValue"));           // 450 + 50, the cancelled order is left out
        Assert.True(d.Cards.Single(c => c.Key == "poValue").IsMoney);
        Assert.Equal(0, d.RequestsByStatus.Single(s => s.Status == RequestStatus.Draft).Count);
        Assert.Contains("Order value", d.SpendTitle);
    }

    [Fact]
    public async Task Officer_SeesWhatNeedsOrderingAndWhatIsLate()
    {
        var h = await CreateAsync();

        var d = await SummaryAsync(h, 4, Roles.ProcurementOfficer);

        Assert.Equal(new[] { "readyToOrder", "openOrders", "overdue", "poValue" }, d.Cards.Select(c => c.Key).ToArray());
        Assert.Equal(1m, Value(d, "readyToOrder"));   // PR-3
        Assert.Equal(1m, Value(d, "openOrders"));     // PO-2 (PO-1 is delivered, PO-3 cancelled)
        Assert.Equal(1m, Value(d, "overdue"));        // PO-2 is two months past its date
        Assert.Equal(500m, Value(d, "poValue"));
        Assert.Equal("danger", d.Cards.Single(c => c.Key == "overdue").Tone);
    }

    [Fact]
    public async Task Admin_SeesAllRequests_AndPendingExcludesTheirOwn()
    {
        var h = await CreateAsync();

        var d = await SummaryAsync(h, 5, Roles.Admin);

        Assert.Equal(9m, Value(d, "total"));      // drafts included
        Assert.Equal(2m, Value(d, "pending"));    // PR-2 and PR-7, but not the admin's own PR-9
        Assert.Equal(1m, Value(d, "approvedThisMonth"));
        Assert.Equal(500m, Value(d, "poValue"));
    }

    [Fact]
    public async Task MonthlySeries_HasSixMonthsOldestFirst_WithZerosFilledIn()
    {
        var h = await CreateAsync();

        var d = await SummaryAsync(h, 4, Roles.ProcurementOfficer);

        Assert.Equal(6, d.MonthlySpend.Count);
        Assert.Equal(DateTime.UtcNow.ToString("yyyy-MM"), d.MonthlySpend.Last().Month);
        Assert.Equal(new[] { 0m, 0m, 0m, 50m, 0m, 450m }, d.MonthlySpend.Select(m => m.Amount).ToArray());
        Assert.Equal(new[] { 0, 0, 0, 1, 0, 1 }, d.MonthlySpend.Select(m => m.Count).ToArray());
        Assert.Equal(d.MonthlySpend.Select(m => m.Month).OrderBy(m => m).ToArray(), d.MonthlySpend.Select(m => m.Month).ToArray());
    }

    [Fact]
    public async Task RequestsByStatus_ListsEveryStatus_EvenWithZero()
    {
        var h = await CreateAsync();

        var d = await SummaryAsync(h, 3, Roles.Manager);

        Assert.Equal(Enum.GetValues<RequestStatus>().Length, d.RequestsByStatus.Count);
        Assert.Equal(3, d.RequestsByStatus.Single(s => s.Status == RequestStatus.Submitted).Count);
        Assert.Equal(1, d.RequestsByStatus.Single(s => s.Status == RequestStatus.Approved).Count);
        Assert.Equal(1, d.RequestsByStatus.Single(s => s.Status == RequestStatus.Cancelled).Count);
    }
}
