using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;
using PurchaseApproval.Api.Services;
using Xunit;

namespace PurchaseApproval.Tests;

public class PurchaseOrderServiceTests
{
    private sealed record Harness(PurchaseOrderService Orders, PurchaseRequestService Requests, AppDbContext Db, FakeCurrentUser Current);

    // Users: 1 requester, 2 manager, 3 officer, 4 admin.
    // Products: 1 (standard price 10), 2 (standard price 25).
    // Vendors: 1 cheap and complete (7 day lead time), 2 quotes only product 1, 3 is inactive,
    //          4 complete but dearer (3 day lead time).
    private static async Task<Harness> CreateAsync()
    {
        var (db, current) = TestDb.Create(1);
        current.Role = Roles.Requester;

        db.Users.AddRange(
            new User { Id = 1, FullName = "Requester", Email = "r@test.example", PasswordHash = "x", RoleId = (int)UserRole.Requester },
            new User { Id = 2, FullName = "Manager", Email = "m@test.example", PasswordHash = "x", RoleId = (int)UserRole.Manager },
            new User { Id = 3, FullName = "Officer", Email = "o@test.example", PasswordHash = "x", RoleId = (int)UserRole.ProcurementOfficer },
            new User { Id = 4, FullName = "Admin", Email = "a@test.example", PasswordHash = "x", RoleId = (int)UserRole.Admin });
        db.Products.AddRange(
            new Product { Id = 1, Sku = "A", Name = "Product A", Category = "Cat", Unit = "Piece", StandardPrice = 10 },
            new Product { Id = 2, Sku = "B", Name = "Product B", Category = "Cat", Unit = "Piece", StandardPrice = 25 });
        db.Vendors.AddRange(
            new Vendor { Id = 1, Code = "V1", Name = "Alpha", Email = "a@v.example", Rating = 4 },
            new Vendor { Id = 2, Code = "V2", Name = "Bravo", Email = "b@v.example", Rating = 4 },
            new Vendor { Id = 3, Code = "V3", Name = "Charlie", Email = "c@v.example", Rating = 4, IsActive = false },
            new Vendor { Id = 4, Code = "V4", Name = "Delta", Email = "d@v.example", Rating = 5 });
        db.VendorProducts.AddRange(
            Quote(1, 1, 9, 5), Quote(1, 2, 24, 7),
            Quote(2, 1, 8, 2),
            Quote(3, 1, 7, 2), Quote(3, 2, 20, 2),
            Quote(4, 1, 12, 3), Quote(4, 2, 20, 3));
        await db.SaveChangesAsync();

        var requests = new PurchaseRequestService(new Repository<PurchaseRequest>(db), new Repository<Product>(db), current);
        var quotes = new VendorQuoteService(new Repository<RequestItem>(db), new Repository<VendorProduct>(db));
        var orders = new PurchaseOrderService(
            new Repository<PurchaseOrder>(db), new Repository<PurchaseRequest>(db), new Repository<Product>(db), quotes, current);
        return new Harness(orders, requests, db, current);
    }

    private static VendorProduct Quote(int vendorId, int productId, decimal price, int leadDays) =>
        new() { VendorId = vendorId, ProductId = productId, QuotedPrice = price, LeadTimeDays = leadDays };

    // A request for 2 x product 1 and 1 x product 2, made by requester 1.
    // Vendor 1 would charge 2 x 9 + 24 = 42, vendor 4 would charge 2 x 12 + 20 = 44.
    private static async Task<int> SubmittedRequestAsync(Harness h, bool approve)
    {
        var created = await h.Requests.CreateAsync(new PurchaseRequestInput
        {
            Title = "Test",
            Items = new()
            {
                new PurchaseRequestItemInput { ProductId = 1, Quantity = 2 },
                new PurchaseRequestItemInput { ProductId = 2, Quantity = 1 }
            }
        });
        await h.Requests.SubmitAsync(created.Id);

        if (approve)
        {
            var entity = await h.Db.PurchaseRequests.SingleAsync(r => r.Id == created.Id);
            entity.Status = RequestStatus.Approved;   // pretend a manager approved it (Step 9 does this for real)
            await h.Db.SaveChangesAsync();
        }
        return created.Id;
    }

    private static PurchaseOrderCreateInput NewOrder(int requestId, int vendorId, int promisedInDays = 10) => new()
    {
        PurchaseRequestId = requestId,
        VendorId = vendorId,
        PromisedDeliveryDate = DateTime.UtcNow.Date.AddDays(promisedInDays)
    };

    private static void BecomeOfficer(Harness h)
    {
        h.Current.UserId = 3;
        h.Current.Role = Roles.ProcurementOfficer;
    }

    private static void BecomeManager(Harness h)
    {
        h.Current.UserId = 2;
        h.Current.Role = Roles.Manager;
    }

    private static void BecomeAdmin(Harness h)
    {
        h.Current.UserId = 4;
        h.Current.Role = Roles.Admin;
    }

    [Fact]
    public async Task VendorOptions_ListActiveVendorsThatQuoteEveryItem_CheapestFirst()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);
        BecomeOfficer(h);

        var options = await h.Orders.GetVendorOptionsAsync(id);

        Assert.Equal(new[] { "V1", "V4" }, options.Select(o => o.VendorCode).ToArray());   // V2 is partial, V3 is inactive
        Assert.Equal(42m, options[0].TotalPrice);
        Assert.Equal(7, options[0].LeadTimeDays);
        Assert.Equal(44m, options[1].TotalPrice);
        Assert.Equal(3, options[1].LeadTimeDays);
    }

    [Fact]
    public async Task Create_FromAnApprovedRequest_UsesVendorPrices_AndMarksTheRequest()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);
        BecomeOfficer(h);

        var order = await h.Orders.CreateAsync(NewOrder(id, 1));

        Assert.Equal(PurchaseOrderStatus.Created, order.Status);
        Assert.Equal(42m, order.TotalAmount);
        Assert.Equal(45m, order.RequestEstimatedTotal);   // 2 x 10 + 25 at standard prices
        Assert.EndsWith("0001", order.PoNumber);
        Assert.Equal("Alpha", order.VendorName);
        Assert.Equal(2, order.Items.Count);
        Assert.True(order.Permissions.CanSend);
        Assert.Equal(RequestStatus.PoCreated, (await h.Requests.GetByIdAsync(id)).Status);
    }

    [Fact]
    public async Task Create_IsRefused_WhenTheRequestIsNotApproved()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: false);
        BecomeOfficer(h);

        await Assert.ThrowsAsync<ConflictException>(() => h.Orders.CreateAsync(NewOrder(id, 1)));
    }

    [Fact]
    public async Task Create_IsRefused_ForVendorsThatCannotSupplyEverything()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);
        BecomeOfficer(h);

        var partial = await Assert.ThrowsAsync<AppException>(() => h.Orders.CreateAsync(NewOrder(id, 2)));
        Assert.True(partial.Errors!.ContainsKey("VendorId"));

        var inactive = await Assert.ThrowsAsync<AppException>(() => h.Orders.CreateAsync(NewOrder(id, 3)));
        Assert.True(inactive.Errors!.ContainsKey("VendorId"));
    }

    [Fact]
    public async Task Create_IsRefused_ForADeliveryDateInThePast()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);
        BecomeOfficer(h);

        var ex = await Assert.ThrowsAsync<AppException>(() => h.Orders.CreateAsync(NewOrder(id, 1, promisedInDays: -1)));

        Assert.True(ex.Errors!.ContainsKey("PromisedDeliveryDate"));
    }

    [Fact]
    public async Task Create_CannotBeRepeatedForTheSameRequest()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);
        BecomeOfficer(h);
        await h.Orders.CreateAsync(NewOrder(id, 1));

        await Assert.ThrowsAsync<ConflictException>(() => h.Orders.CreateAsync(NewOrder(id, 4)));
    }

    [Fact]
    public async Task StatusFlow_SendDeliverAndTheRulesAroundThem()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);
        BecomeOfficer(h);
        var order = await h.Orders.CreateAsync(NewOrder(id, 1));

        Assert.Equal(PurchaseOrderStatus.Sent, (await h.Orders.SendAsync(order.Id)).Status);
        await Assert.ThrowsAsync<ConflictException>(() => h.Orders.SendAsync(order.Id));   // not twice

        var future = await Assert.ThrowsAsync<AppException>(
            () => h.Orders.DeliverAsync(order.Id, DateTime.UtcNow.Date.AddDays(3)));
        Assert.True(future.Errors!.ContainsKey("DeliveredDate"));

        var delivered = await h.Orders.DeliverAsync(order.Id, null);   // no date means today
        Assert.Equal(PurchaseOrderStatus.Delivered, delivered.Status);
        Assert.Equal(DateTime.UtcNow.Date, delivered.DeliveredDate!.Value.Date);
        Assert.False(delivered.Permissions.CanDeliver);
        Assert.False(delivered.Permissions.CanCancel);

        await Assert.ThrowsAsync<ConflictException>(() => h.Orders.CancelAsync(order.Id));
    }

    [Fact]
    public async Task Cancel_ReturnsTheRequestToApproved_AndAllowsANewOrder()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);
        BecomeOfficer(h);
        var first = await h.Orders.CreateAsync(NewOrder(id, 1));

        var cancelled = await h.Orders.CancelAsync(first.Id);

        Assert.Equal(PurchaseOrderStatus.Cancelled, cancelled.Status);
        Assert.Equal(RequestStatus.Approved, (await h.Requests.GetByIdAsync(id)).Status);

        var second = await h.Orders.CreateAsync(NewOrder(id, 4));
        Assert.EndsWith("0002", second.PoNumber);
        Assert.Equal(44m, second.TotalAmount);
    }

    [Fact]
    public async Task Permissions_DependOnTheRole()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);
        BecomeOfficer(h);
        var order = await h.Orders.CreateAsync(NewOrder(id, 1));
        Assert.True(order.Permissions.CanSend);
        Assert.True(order.Permissions.CanDeliver);
        Assert.True(order.Permissions.CanCancel);

        BecomeManager(h);   // a manager may look, but not change
        var asManager = await h.Orders.GetByIdAsync(order.Id);
        Assert.False(asManager.Permissions.CanSend);
        Assert.False(asManager.Permissions.CanDeliver);
        Assert.False(asManager.Permissions.CanCancel);
        Assert.Single((await h.Orders.GetPagedAsync(new PurchaseOrderQuery())).Items);

        BecomeAdmin(h);
        Assert.True((await h.Orders.GetByIdAsync(order.Id)).Permissions.CanCancel);
    }

    [Fact]
    public async Task Overdue_FlagsOnlyOpenOrdersPastTheirPromisedDate()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);
        BecomeOfficer(h);
        var today = DateTime.UtcNow.Date;

        h.Db.PurchaseOrders.AddRange(
            new PurchaseOrder { PoNumber = "PO-X1", PurchaseRequestId = id, VendorId = 1, OrderDate = today.AddDays(-10), PromisedDeliveryDate = today.AddDays(-2), Status = PurchaseOrderStatus.Sent },
            new PurchaseOrder { PoNumber = "PO-X2", PurchaseRequestId = id, VendorId = 1, OrderDate = today.AddDays(-10), PromisedDeliveryDate = today.AddDays(-2), DeliveredDate = today.AddDays(-3), Status = PurchaseOrderStatus.Delivered },
            new PurchaseOrder { PoNumber = "PO-X3", PurchaseRequestId = id, VendorId = 1, OrderDate = today, PromisedDeliveryDate = today.AddDays(5), Status = PurchaseOrderStatus.Created });
        await h.Db.SaveChangesAsync();

        var list = await h.Orders.GetPagedAsync(new PurchaseOrderQuery());

        Assert.True(list.Items.Single(i => i.PoNumber == "PO-X1").IsOverdue);
        Assert.False(list.Items.Single(i => i.PoNumber == "PO-X2").IsOverdue);
        Assert.False(list.Items.Single(i => i.PoNumber == "PO-X3").IsOverdue);
    }

    [Fact]
    public async Task ARequest_OffersCreateOrder_OnlyToOfficersAndAdmins_WhenApproved()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h, approve: true);

        Assert.False((await h.Requests.GetByIdAsync(id)).Permissions.CanCreateOrder);   // the requester

        BecomeOfficer(h);
        Assert.True((await h.Requests.GetByIdAsync(id)).Permissions.CanCreateOrder);

        BecomeManager(h);
        Assert.False((await h.Requests.GetByIdAsync(id)).Permissions.CanCreateOrder);

        BecomeOfficer(h);
        await h.Orders.CreateAsync(NewOrder(id, 1));
        Assert.False((await h.Requests.GetByIdAsync(id)).Permissions.CanCreateOrder);   // already ordered
    }
}
