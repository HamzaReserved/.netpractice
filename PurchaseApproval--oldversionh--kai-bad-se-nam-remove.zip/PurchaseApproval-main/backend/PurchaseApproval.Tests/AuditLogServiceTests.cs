using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Services;
using Xunit;

namespace PurchaseApproval.Tests;

public class AuditLogServiceTests
{
    private sealed record Harness(AuditLogService Service, AppDbContext Db, DateTime Today);

    // Four audit rows on four different days:
    //   1 Alice created a vendor (3 days ago)      2 Alice updated it (2 days ago)
    //   3 Bob created a request (yesterday)        4 a failed login by nobody known (today)
    private static async Task<Harness> CreateAsync()
    {
        var (db, _) = TestDb.Create(userId: null);   // nobody logged in, so saving adds no audit rows of its own
        var today = DateTime.UtcNow.Date;

        db.Users.AddRange(
            new User { Id = 1, FullName = "Alice", Email = "a@test.example", PasswordHash = "x", RoleId = (int)UserRole.Admin },
            new User { Id = 2, FullName = "Bob", Email = "b@test.example", PasswordHash = "x", RoleId = (int)UserRole.Manager });
        db.AuditLogs.AddRange(
            new AuditLog { UserId = 1, Action = "Create", EntityName = "Vendor", EntityId = 10, NewValues = "{\"Name\":\"Alpha\"}", Timestamp = today.AddDays(-3).AddHours(10) },
            new AuditLog { UserId = 1, Action = "Update", EntityName = "Vendor", EntityId = 10, OldValues = "{\"Rating\":3}", NewValues = "{\"Rating\":5}", Timestamp = today.AddDays(-2).AddHours(10) },
            new AuditLog { UserId = 2, Action = "Create", EntityName = "PurchaseRequest", EntityId = 20, Timestamp = today.AddDays(-1).AddHours(10) },
            new AuditLog { UserId = null, Action = "LoginFailed", EntityName = "User", Timestamp = today.AddHours(1) });
        await db.SaveChangesAsync();

        return new Harness(new AuditLogService(db), db, today);
    }

    [Fact]
    public async Task Filters_ByUser_Entity_AndAction()
    {
        var h = await CreateAsync();

        Assert.Equal(2, (await h.Service.GetPagedAsync(new AuditLogQuery { UserId = 1 })).TotalCount);
        Assert.Single((await h.Service.GetPagedAsync(new AuditLogQuery { EntityName = "PurchaseRequest" })).Items);

        var updates = await h.Service.GetPagedAsync(new AuditLogQuery { Action = "Update" });
        Assert.Equal("Alice", updates.Items.Single().UserName);

        var combined = await h.Service.GetPagedAsync(new AuditLogQuery { UserId = 1, Action = "Create" });
        Assert.Equal(10, combined.Items.Single().EntityId);
    }

    [Fact]
    public async Task DateRange_IncludesBothEndDays()
    {
        var h = await CreateAsync();

        var range = await h.Service.GetPagedAsync(new AuditLogQuery { From = h.Today.AddDays(-2), To = h.Today.AddDays(-1) });

        Assert.Equal(new[] { "PurchaseRequest", "Vendor" }, range.Items.Select(i => i.EntityName).ToArray());   // newest first
    }

    [Fact]
    public async Task Search_LooksInTheNamesAndInTheChangedValues()
    {
        var h = await CreateAsync();

        Assert.Equal("Update", (await h.Service.GetPagedAsync(new AuditLogQuery { Search = "Rating" })).Items.Single().Action);
        Assert.Equal("Create", (await h.Service.GetPagedAsync(new AuditLogQuery { Search = "Alpha" })).Items.Single().Action);
        Assert.Equal(2, (await h.Service.GetPagedAsync(new AuditLogQuery { Search = "Vendor" })).TotalCount);
    }

    [Fact]
    public async Task Default_IsNewestFirst_AndNamesAreFilledIn()
    {
        var h = await CreateAsync();

        var all = await h.Service.GetPagedAsync(new AuditLogQuery());

        Assert.Equal(new[] { "(not logged in)", "Bob", "Alice", "Alice" }, all.Items.Select(i => i.UserName).ToArray());
        Assert.Equal(new[] { "LoginFailed", "Create", "Update", "Create" }, all.Items.Select(i => i.Action).ToArray());
    }

    [Fact]
    public async Task Filters_ListTheDistinctEntitiesAndActions()
    {
        var h = await CreateAsync();

        var filters = await h.Service.GetFiltersAsync();

        Assert.Equal(new[] { "PurchaseRequest", "User", "Vendor" }, filters.Entities.ToArray());
        Assert.Equal(new[] { "Create", "LoginFailed", "Update" }, filters.Actions.ToArray());
    }

    [Fact]
    public async Task AiDecisions_ShowWhatWasRecommended_WhatWasChosen_AndWhy()
    {
        var h = await CreateAsync();
        h.Db.Vendors.AddRange(
            new Vendor { Id = 1, Code = "V1", Name = "Alpha Ltd", Email = "a@v.example", Rating = 4 },
            new Vendor { Id = 2, Code = "V2", Name = "Bravo Ltd", Email = "b@v.example", Rating = 4 });
        var request = new PurchaseRequest { RequestNumber = "PR-77", Title = "T", RequesterId = 1 };
        h.Db.PurchaseRequests.Add(request);
        await h.Db.SaveChangesAsync();

        var t = h.Today;
        h.Db.AiRecommendationLogs.AddRange(
            new AiRecommendationLog
            {
                PurchaseRequestId = request.Id, RequestedBy = 2, InputJson = "{}", OutputJson = "{}",
                RecommendedVendorId = 1, FinalVendorId = 1, WasOverridden = false, CreatedAt = t.AddHours(1)
            },
            new AiRecommendationLog
            {
                PurchaseRequestId = request.Id, RequestedBy = 2, InputJson = "{}", OutputJson = "{}",
                RecommendedVendorId = 1, FinalVendorId = 2, WasOverridden = true, OverrideReason = "Cheaper", CreatedAt = t.AddHours(2)
            },
            new AiRecommendationLog
            {
                PurchaseRequestId = request.Id, RequestedBy = 2, InputJson = "{}", OutputJson = "{}",
                RecommendedVendorId = 2, FinalVendorId = null, CreatedAt = t.AddHours(3)
            });
        await h.Db.SaveChangesAsync();

        var all = await h.Service.GetAiDecisionsAsync(new AiDecisionQuery());

        Assert.Equal(new[] { "Unused", "Overridden", "Accepted" }, all.Items.Select(i => i.Outcome).ToArray());   // newest first
        Assert.Equal("PR-77", all.Items[0].RequestNumber);
        Assert.Equal("Bob", all.Items[0].RequestedByName);
        Assert.Null(all.Items[0].FinalVendorName);

        var overridden = all.Items[1];
        Assert.Equal("Alpha Ltd", overridden.RecommendedVendorName);
        Assert.Equal("Bravo Ltd", overridden.FinalVendorName);
        Assert.Equal("Cheaper", overridden.OverrideReason);

        Assert.Single((await h.Service.GetAiDecisionsAsync(new AiDecisionQuery { Outcome = "Overridden" })).Items);
        Assert.Single((await h.Service.GetAiDecisionsAsync(new AiDecisionQuery { Outcome = "Accepted" })).Items);
    }
}
