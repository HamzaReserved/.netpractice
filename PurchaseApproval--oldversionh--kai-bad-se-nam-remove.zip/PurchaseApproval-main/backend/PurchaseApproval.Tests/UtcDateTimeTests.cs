using PurchaseApproval.Api.Data;
using Xunit;

namespace PurchaseApproval.Tests;

public class UtcDateTimeTests
{
    [Fact]
    public void DateTimeFromTheDatabase_IsMarkedAsUtc()
    {
        var converter = new UtcDateTimeConverter();
        var fromDb = new DateTime(2026, 10, 6, 5, 58, 13, DateTimeKind.Unspecified);

        var result = (DateTime)converter.ConvertFromProvider(fromDb)!;

        Assert.Equal(DateTimeKind.Utc, result.Kind);
        Assert.Equal(fromDb.Ticks, result.Ticks);
    }

    [Fact]
    public void NullableDateTime_KeepsNull_AndMarksValuesAsUtc()
    {
        var converter = new NullableUtcDateTimeConverter();

        Assert.Null(converter.ConvertFromProvider(null));

        var result = (DateTime?)converter.ConvertFromProvider(new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Unspecified));
        Assert.Equal(DateTimeKind.Utc, result!.Value.Kind);
    }
}
