using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Services;

namespace PurchaseApproval.Tests;

public class FakeCurrentUser : ICurrentUserService
{
    public int? UserId { get; set; }
    public string? Role { get; set; }
}

public static class TestDb
{
    // A fresh, empty, throw-away database for every test
    public static (AppDbContext Db, FakeCurrentUser Current) Create(int? userId = 42)
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        var current = new FakeCurrentUser { UserId = userId };
        var db = new AppDbContext(options, current);
        db.Roles.AddRange(
            new Role { RoleId = (int)UserRole.Requester, Name = nameof(UserRole.Requester) },
            new Role { RoleId = (int)UserRole.Manager, Name = nameof(UserRole.Manager) },
            new Role { RoleId = (int)UserRole.ProcurementOfficer, Name = nameof(UserRole.ProcurementOfficer) },
            new Role { RoleId = (int)UserRole.Admin, Name = nameof(UserRole.Admin) });
        db.SaveChanges();
        return (db, current);
    }
}
