using System.IdentityModel.Tokens.Jwt;
using Microsoft.Extensions.Configuration;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Services;

namespace PurchaseApproval.Tests;

public class TokenServiceTests
{
    [Fact]
    public void CreateToken_IncludesRoleIdAndPreservesExistingClaims()
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Jwt:Key"] = "a sufficiently long test signing key for HMAC-SHA256",
                ["Jwt:ExpiryMinutes"] = "60",
                ["Jwt:Issuer"] = "test-issuer",
                ["Jwt:Audience"] = "test-audience"
            })
            .Build();
        var user = new User
        {
            Id = 17,
            FullName = "Test User",
            Email = "test@example.com",
            RoleId = (int)UserRole.Manager,
            Role = new Role { RoleId = (int)UserRole.Manager, Name = nameof(UserRole.Manager) }
        };

        var (tokenValue, _) = new TokenService(configuration).CreateToken(user);
        var token = new JwtSecurityTokenHandler().ReadJwtToken(tokenValue);

        Assert.Equal("17", token.Claims.Single(claim => claim.Type == JwtClaimTypes.UserId).Value);
        Assert.Equal("Test User", token.Claims.Single(claim => claim.Type == JwtClaimTypes.Name).Value);
        Assert.Equal("test@example.com", token.Claims.Single(claim => claim.Type == JwtClaimTypes.Email).Value);
        Assert.Equal(nameof(UserRole.Manager), token.Claims.Single(claim => claim.Type == JwtClaimTypes.Role).Value);
        Assert.Equal(((int)UserRole.Manager).ToString(), token.Claims.Single(claim => claim.Type == JwtClaimTypes.RoleId).Value);
        Assert.DoesNotContain(token.Claims, claim => claim.Type.StartsWith("http://schemas."));
    }
}
