using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Models;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace PurchaseApproval.Tests;

public class PagingTests
{
    [Fact]
    public async Task SecondPage_ReturnsTheNextItems_WithCorrectTotals()
    {
        var (db, _) = TestDb.Create();
        for (int i = 1; i <= 25; i++)
        {
            db.Vendors.Add(new Vendor { Code = $"V{i:00}", Name = $"Vendor {i:00}", Email = $"v{i}@test.example", Rating = 3 });
        }
        await db.SaveChangesAsync();

        var result = await db.Vendors.OrderBy(v => v.Code).ToPagedResultAsync(2, 10);

        Assert.Equal(10, result.Items.Count);
        Assert.Equal("V11", result.Items[0].Code);
        Assert.Equal(25, result.TotalCount);
        Assert.Equal(3, result.TotalPages);
        Assert.True(result.HasPrevious);
        Assert.True(result.HasNext);
    }

    [Fact]
    public void PagedQuery_ClampsBadValues()
    {
        var query = new PagedQuery { Page = -5, PageSize = 5000 };

        Assert.Equal(1, query.Page);
        Assert.Equal(100, query.PageSize);
    }
}
