using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;
using PurchaseApproval.Api.Services;
using Xunit;

namespace PurchaseApproval.Tests;

public class ApprovalServiceTests
{
    private sealed record Harness(PurchaseRequestService Requests, ApprovalService Approvals, AppDbContext Db, FakeCurrentUser Current);

    // Users: 1 requester, 2 manager, 3 admin. Product 1 costs 10. The current user starts as requester 1.
    private static async Task<Harness> CreateAsync()
    {
        var (db, current) = TestDb.Create(1);
        current.Role = Roles.Requester;

        db.Users.AddRange(
            new User { Id = 1, FullName = "Requester", Email = "r@test.example", PasswordHash = "x", RoleId = (int)UserRole.Requester },
            new User { Id = 2, FullName = "Manager", Email = "m@test.example", PasswordHash = "x", RoleId = (int)UserRole.Manager },
            new User { Id = 3, FullName = "Admin", Email = "a@test.example", PasswordHash = "x", RoleId = (int)UserRole.Admin });
        db.Products.Add(new Product { Id = 1, Sku = "A", Name = "Product A", Category = "Cat", Unit = "Piece", StandardPrice = 10 });
        await db.SaveChangesAsync();

        var requests = new PurchaseRequestService(new Repository<PurchaseRequest>(db), new Repository<Product>(db), current);
        var approvals = new ApprovalService(new Repository<PurchaseRequest>(db), current, requests);
        return new Harness(requests, approvals, db, current);
    }

    private static PurchaseRequestInput Input() => new()
    {
        Title = "Test",
        Items = new() { new PurchaseRequestItemInput { ProductId = 1, Quantity = 1 } }
    };

    // Creates and submits a request as whoever is the current user, and returns its id
    private static async Task<int> SubmittedRequestAsync(Harness h)
    {
        var created = await h.Requests.CreateAsync(Input());
        await h.Requests.SubmitAsync(created.Id);
        return created.Id;
    }

    private static void BecomeManager(Harness h)
    {
        h.Current.UserId = 2;
        h.Current.Role = Roles.Manager;
    }

    private static void BecomeAdmin(Harness h)
    {
        h.Current.UserId = 3;
        h.Current.Role = Roles.Admin;
    }

    [Fact]
    public async Task Approve_ChangesTheStatus_RecordsTheDecision_AndEndsTheChoice()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h);
        BecomeManager(h);
        Assert.True((await h.Requests.GetByIdAsync(id)).Permissions.CanDecide);

        var approved = await h.Approvals.ApproveAsync(id, "  Looks good  ");

        Assert.Equal(RequestStatus.Approved, approved.Status);
        var decision = Assert.Single(approved.Approvals);
        Assert.Equal(ApprovalDecision.Approved, decision.Decision);
        Assert.Equal("Looks good", decision.Comments);
        Assert.Equal("Manager", decision.ApproverName);
        Assert.False(approved.Permissions.CanDecide);
    }

    [Fact]
    public async Task Reject_NeedsAComment()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h);
        BecomeManager(h);

        var ex = await Assert.ThrowsAsync<AppException>(() => h.Approvals.RejectAsync(id, "   "));

        Assert.True(ex.Errors!.ContainsKey("Comments"));
        Assert.Equal(RequestStatus.Submitted, (await h.Requests.GetByIdAsync(id)).Status);
    }

    [Fact]
    public async Task Reject_LetsTheRequesterReviseAndResubmit_AndHistoryKeepsBothDecisions()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h);
        BecomeManager(h);
        await h.Approvals.RejectAsync(id, "Budget not available");

        h.Current.UserId = 1;
        h.Current.Role = Roles.Requester;
        var rejected = await h.Requests.GetByIdAsync(id);
        Assert.Equal(RequestStatus.Rejected, rejected.Status);
        Assert.True(rejected.Permissions.CanRevise);

        await h.Requests.ReviseAsync(id);
        await h.Requests.SubmitAsync(id);

        BecomeManager(h);
        var approved = await h.Approvals.ApproveAsync(id, null);

        Assert.Equal(2, approved.Approvals.Count);
        Assert.Contains(approved.Approvals, a => a.Decision == ApprovalDecision.Rejected && a.Comments == "Budget not available");
        Assert.Contains(approved.Approvals, a => a.Decision == ApprovalDecision.Approved);
    }

    [Fact]
    public async Task NobodyCanDecideOnTheirOwnRequest_ButSomeoneElseCan()
    {
        var h = await CreateAsync();
        BecomeAdmin(h);
        var id = await SubmittedRequestAsync(h);   // the admin submits their own request

        await Assert.ThrowsAsync<ForbiddenException>(() => h.Approvals.ApproveAsync(id, null));
        Assert.False((await h.Requests.GetByIdAsync(id)).Permissions.CanDecide);

        BecomeManager(h);
        Assert.Equal(RequestStatus.Approved, (await h.Approvals.ApproveAsync(id, null)).Status);
    }

    [Fact]
    public async Task ADecisionCannotBeMadeTwice()
    {
        var h = await CreateAsync();
        var id = await SubmittedRequestAsync(h);
        BecomeManager(h);
        await h.Approvals.ApproveAsync(id, null);

        await Assert.ThrowsAsync<ConflictException>(() => h.Approvals.ApproveAsync(id, null));
        await Assert.ThrowsAsync<ConflictException>(() => h.Approvals.RejectAsync(id, "Changed my mind"));
    }

    [Fact]
    public async Task Drafts_AreHiddenFromManagers_AndNotDecidableByAdmins()
    {
        var h = await CreateAsync();
        var draft = await h.Requests.CreateAsync(Input());   // a draft of requester 1

        BecomeManager(h);
        await Assert.ThrowsAsync<NotFoundException>(() => h.Approvals.ApproveAsync(draft.Id, null));

        BecomeAdmin(h);
        await Assert.ThrowsAsync<ConflictException>(() => h.Approvals.ApproveAsync(draft.Id, null));
    }

    [Fact]
    public async Task PendingList_ShowsOthersSubmittedRequests_OldestFirst()
    {
        var h = await CreateAsync();
        var first = await SubmittedRequestAsync(h);
        var second = await SubmittedRequestAsync(h);
        await h.Requests.CreateAsync(Input());   // a draft, which must never appear
        BecomeAdmin(h);
        var adminOwn = await SubmittedRequestAsync(h);

        var query = new PurchaseRequestQuery { AwaitingMyApproval = true, SortBy = "submitted" };

        BecomeManager(h);
        var managerList = await h.Requests.GetPagedAsync(query);
        Assert.Equal(new[] { first, second, adminOwn }, managerList.Items.Select(i => i.Id).ToArray());

        BecomeAdmin(h);
        var adminList = await h.Requests.GetPagedAsync(query);
        Assert.Equal(new[] { first, second }, adminList.Items.Select(i => i.Id).ToArray());   // not the admin's own
    }
}
