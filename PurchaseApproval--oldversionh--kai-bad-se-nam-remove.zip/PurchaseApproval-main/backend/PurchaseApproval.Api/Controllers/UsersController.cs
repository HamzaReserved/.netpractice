using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Services;

namespace PurchaseApproval.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = Roles.Admin)]   // the whole controller is for administrators only
public class UsersController : ControllerBase
{
    private readonly IUserService _service;

    public UsersController(IUserService service) => _service = service;

    [HttpGet]
    public async Task<ActionResult<ApiResponse<PagedResult<UserDto>>>> GetAll([FromQuery] UserQuery query) =>
        Ok(ApiResponse<PagedResult<UserDto>>.Ok(await _service.GetPagedAsync(query)));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ApiResponse<UserDto>>> GetById(int id) =>
        Ok(ApiResponse<UserDto>.Ok(await _service.GetByIdAsync(id)));

    [HttpPost]
    public async Task<ActionResult<ApiResponse<UserDto>>> Create(UserCreateInput input)
    {
        var created = await _service.CreateAsync(input);
        return CreatedAtAction(nameof(GetById), new { id = created.Id },
            ApiResponse<UserDto>.Ok(created, "User created."));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ApiResponse<UserDto>>> Update(int id, UserUpdateInput input) =>
        Ok(ApiResponse<UserDto>.Ok(await _service.UpdateAsync(id, input), "User updated."));

    [HttpPost("{id:int}/reset-password")]
    public async Task<IActionResult> ResetPassword(int id, ResetPasswordInput input)
    {
        await _service.ResetPasswordAsync(id, input.NewPassword);
        return NoContent();
    }
}
