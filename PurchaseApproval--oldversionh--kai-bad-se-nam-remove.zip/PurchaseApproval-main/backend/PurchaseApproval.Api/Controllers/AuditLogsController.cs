using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Services;

namespace PurchaseApproval.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = Roles.Admin)]
public class AuditLogsController : ControllerBase
{
    private readonly IAuditLogService _service;

    public AuditLogsController(IAuditLogService service) => _service = service;

    [HttpGet]
    public async Task<ActionResult<ApiResponse<PagedResult<AuditLogDto>>>> GetAll(
        [FromQuery] AuditLogQuery query,
        CancellationToken cancellationToken) =>
        Ok(ApiResponse<PagedResult<AuditLogDto>>.Ok(await _service.GetPagedAsync(query, cancellationToken)));

    [HttpGet("filters")]
    public async Task<ActionResult<ApiResponse<AuditFiltersDto>>> GetFilters() =>
        Ok(ApiResponse<AuditFiltersDto>.Ok(await _service.GetFiltersAsync()));

    [HttpGet("ai-decisions")]
    public async Task<ActionResult<ApiResponse<PagedResult<AiDecisionDto>>>> GetAiDecisions([FromQuery] AiDecisionQuery query) =>
        Ok(ApiResponse<PagedResult<AiDecisionDto>>.Ok(await _service.GetAiDecisionsAsync(query)));
}
