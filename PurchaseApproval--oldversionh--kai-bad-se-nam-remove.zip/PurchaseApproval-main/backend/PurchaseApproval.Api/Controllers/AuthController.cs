using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Services;

namespace PurchaseApproval.Api.Controllers;

// http req login ki acept krkai service ko pass krta hai(Loginasync) 
// aur service se response lekr client ko return krta hai

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _auth;

    public AuthController(IAuthService auth) => _auth = auth;

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<ApiResponse<LoginResponse>>> Login(LoginRequest request)
    {
        var result = await _auth.LoginAsync(request);
        if (result == null)
            throw new AppException("Invalid email or password.", 401);

        return Ok(ApiResponse<LoginResponse>.Ok(result, "Login successful."));
    }

    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout()
    {
        var userId = int.Parse(User.FindFirstValue(JwtClaimTypes.UserId)!);
        await _auth.LogoutAsync(userId);
        return NoContent();
    }

    [HttpGet("me")]
    [Authorize]
    public IActionResult Me() => Ok(ApiResponse<object>.Ok(new
    {
        id = User.FindFirstValue(JwtClaimTypes.UserId),
        name = User.Identity?.Name,
        email = User.FindFirstValue(JwtClaimTypes.Email),
        role = User.FindFirstValue(JwtClaimTypes.Role)
    }));
}
