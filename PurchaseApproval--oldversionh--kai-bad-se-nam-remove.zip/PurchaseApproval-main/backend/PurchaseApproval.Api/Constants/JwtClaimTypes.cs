namespace PurchaseApproval.Api.Constants;

public static class JwtClaimTypes
{
    public const string UserId = "sub";
    public const string Name = "name";
    public const string Email = "email";
    public const string Role = "role";
    public const string RoleId = "role_id";
}
