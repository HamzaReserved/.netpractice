using PurchaseApproval.Api.Common;

namespace PurchaseApproval.Api.Dtos;

public class AuditLogDto
{
    public int Id { get; set; }
    public DateTime Timestamp { get; set; }
    public int? UserId { get; set; }
    public string UserName { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string EntityName { get; set; } = string.Empty;
    public int? EntityId { get; set; }
    public string? OldValues { get; set; }
    public string? NewValues { get; set; }
}

// ?userId=3&entityName=Vendor&action=Update&from=2026-10-01&to=2026-10-31&search=Rating
public class AuditLogQuery : PagedQuery
{
    public int? UserId { get; set; }
    public string? EntityName { get; set; }
    public string? Action { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
}

// The choices for the filter drop-downs
public class AuditFiltersDto
{
    public List<string> Entities { get; set; } = new();
    public List<string> Actions { get; set; } = new();
}

public class AiDecisionDto
{
    public int Id { get; set; }
    public DateTime CreatedAt { get; set; }
    public int PurchaseRequestId { get; set; }
    public string RequestNumber { get; set; } = string.Empty;
    public string RequestedByName { get; set; } = string.Empty;
    public string RecommendedVendorName { get; set; } = string.Empty;
    public string? FinalVendorName { get; set; }
    public string Outcome { get; set; } = string.Empty;   // Accepted, Overridden or Unused
    public string? OverrideReason { get; set; }
}

// ?outcome=Overridden
public class AiDecisionQuery : PagedQuery
{
    public string? Outcome { get; set; }
}
