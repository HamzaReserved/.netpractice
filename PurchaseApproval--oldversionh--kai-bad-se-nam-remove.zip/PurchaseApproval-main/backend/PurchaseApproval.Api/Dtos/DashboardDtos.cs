using PurchaseApproval.Api.Models;

namespace PurchaseApproval.Api.Dtos;

// One number box on the dashboard. The server chooses which boxes each role gets.
public class DashboardCardDto
{
    public string Key { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public decimal Value { get; set; }
    public bool IsMoney { get; set; }
    public string Tone { get; set; } = "primary";   // primary, success, warning, danger or secondary
    public string? Hint { get; set; }
    public string? Link { get; set; }               // the screen the box leads to
}

public class StatusCountDto
{
    public RequestStatus Status { get; set; }
    public int Count { get; set; }
}

public class MonthPointDto
{
    public string Month { get; set; } = string.Empty;   // 2026-10
    public string Label { get; set; } = string.Empty;   // Oct 2026
    public decimal Amount { get; set; }
    public int Count { get; set; }
}

public class DashboardDto
{
    public string Scope { get; set; } = string.Empty;
    public DateTime GeneratedAt { get; set; }
    public List<DashboardCardDto> Cards { get; set; } = new();
    public List<StatusCountDto> RequestsByStatus { get; set; } = new();
    public string SpendTitle { get; set; } = string.Empty;
    public List<MonthPointDto> MonthlySpend { get; set; } = new();
}
