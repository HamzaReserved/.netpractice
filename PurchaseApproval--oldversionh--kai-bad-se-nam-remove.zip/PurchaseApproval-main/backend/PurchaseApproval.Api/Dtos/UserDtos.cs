using System.ComponentModel.DataAnnotations;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Models;

namespace PurchaseApproval.Api.Dtos;

// What the API sends back. There is deliberately no password field.
public class UserDto
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public int RoleId { get; set; }
    public UserRole Role { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class UserCreateInput
{
    [Required(ErrorMessage = "Full name is required.")]
    [StringLength(150, ErrorMessage = "Full name can be at most 150 characters.")]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [StringLength(150, ErrorMessage = "Email can be at most 150 characters.")]
    public string Email { get; set; } = string.Empty;

    [Range(1, int.MaxValue, ErrorMessage = "Select a valid role.")]
    public int RoleId { get; set; }

    [Required(ErrorMessage = "Password is required.")]
    [RegularExpression(PasswordRule.Pattern, ErrorMessage = PasswordRule.Message)]
    public string Password { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;
}

// Editing never changes the password. There is a separate reset for that.
public class UserUpdateInput
{
    [Required(ErrorMessage = "Full name is required.")]
    [StringLength(150, ErrorMessage = "Full name can be at most 150 characters.")]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [StringLength(150, ErrorMessage = "Email can be at most 150 characters.")]
    public string Email { get; set; } = string.Empty;

    [Range(1, int.MaxValue, ErrorMessage = "Select a valid role.")]
    public int RoleId { get; set; }

    public bool IsActive { get; set; } = true;
}

public class ResetPasswordInput
{
    [Required(ErrorMessage = "New password is required.")]
    [RegularExpression(PasswordRule.Pattern, ErrorMessage = PasswordRule.Message)]
    public string NewPassword { get; set; } = string.Empty;
}

// ?page=1&pageSize=10&search=ali&role=Manager&isActive=true&sortBy=email
public class UserQuery : PagedQuery
{
    public UserRole? Role { get; set; }
    public bool? IsActive { get; set; }
}
