namespace PurchaseApproval.Api.Common;

// One password rule, used everywhere a password is chosen
public static class PasswordRule
{
    public const string Pattern = @"^(?=.*[A-Za-z])(?=.*\d).{8,100}$";
    public const string Message = "Password must be 8 to 100 characters and contain at least one letter and one number.";
}
