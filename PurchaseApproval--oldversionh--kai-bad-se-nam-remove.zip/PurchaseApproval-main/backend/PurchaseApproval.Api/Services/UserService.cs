using System.Linq.Expressions;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;

namespace PurchaseApproval.Api.Services;

public interface IUserService
{
    Task<PagedResult<UserDto>> GetPagedAsync(UserQuery query);
    Task<UserDto> GetByIdAsync(int id);
    Task<UserDto> CreateAsync(UserCreateInput input);
    Task<UserDto> UpdateAsync(int id, UserUpdateInput input);
    Task ResetPasswordAsync(int id, string newPassword);
}

public class UserService : IUserService
{
    private readonly IRepository<User> _users;
    private readonly AppDbContext _db;
    private readonly ICurrentUserService _currentUser;
    private readonly IAuditService _audit;
    private readonly PasswordHasher<User> _hasher = new();

    public UserService(IRepository<User> users, AppDbContext db, ICurrentUserService currentUser, IAuditService audit)
    {
        _users = users;
        _db = db;
        _currentUser = currentUser;
        _audit = audit;
    }

    private static readonly Expression<Func<User, UserDto>> Projection = u => new UserDto
    {
        Id = u.Id,
        FullName = u.FullName,
        Email = u.Email,
        RoleId = u.RoleId,
        Role = (UserRole)u.RoleId,
        IsActive = u.IsActive,
        CreatedAt = u.CreatedAt,
        UpdatedAt = u.UpdatedAt
    };

    private static readonly Func<User, UserDto> ToDto = Projection.Compile();

    private int CurrentUserId => _currentUser.UserId ?? throw new AppException("You are not logged in.", 401);

    public async Task<PagedResult<UserDto>> GetPagedAsync(UserQuery q)
    {
        var query = _users.Query();

        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            var s = q.Search.Trim();
            query = query.Where(u => u.FullName.Contains(s) || u.Email.Contains(s));
        }

        if (q.Role.HasValue)
        {
            var roleId = (int)q.Role.Value;
            query = query.Where(u => u.RoleId == roleId);
        }

        if (q.IsActive.HasValue)
        {
            var active = q.IsActive.Value;
            query = query.Where(u => u.IsActive == active);
        }

        return await ApplySort(query, q.SortBy, q.Descending)
            .ThenBy(u => u.Id)
            .Select(Projection)
            .ToPagedResultAsync(q.Page, q.PageSize);
    }

    public async Task<UserDto> GetByIdAsync(int id)
    {
        var user = await _users.Query().FirstOrDefaultAsync(u => u.Id == id)
            ?? throw new NotFoundException($"User {id} was not found.");
        return ToDto(user);
    }

    public async Task<UserDto> CreateAsync(UserCreateInput input)
    {
        var role = await GetRoleAsync(input.RoleId);
        var email = input.Email.Trim();
        await EnsureEmailFreeAsync(email, 0);

        var user = new User
        {
            FullName = input.FullName.Trim(),
            Email = email,
            RoleId = role.RoleId,
            IsActive = input.IsActive
        };
        user.PasswordHash = _hasher.HashPassword(user, input.Password);   // only the hash is stored

        await _users.AddAsync(user);
        await _users.SaveChangesAsync();
        return ToDto(user);
    }

    public async Task<UserDto> UpdateAsync(int id, UserUpdateInput input)
    {
        var user = await _users.GetByIdAsync(id)
            ?? throw new NotFoundException($"User {id} was not found.");
        var role = await GetRoleAsync(input.RoleId);

        // An admin may not lock themselves out
        if (user.Id == CurrentUserId)
        {
            if (!input.IsActive)
                throw new ConflictException("You cannot deactivate your own account.");
            if (role.RoleId != (int)UserRole.Admin)
                throw new ConflictException("You cannot remove your own administrator role.");
        }

        var email = input.Email.Trim();
        await EnsureEmailFreeAsync(email, id);

        user.FullName = input.FullName.Trim();
        user.Email = email;
        user.RoleId = role.RoleId;
        user.IsActive = input.IsActive;

        await _users.SaveChangesAsync();
        return ToDto(user);
    }

    public async Task ResetPasswordAsync(int id, string newPassword)
    {
        var user = await _users.GetByIdAsync(id)
            ?? throw new NotFoundException($"User {id} was not found.");

        user.PasswordHash = _hasher.HashPassword(user, newPassword);
        await _users.SaveChangesAsync();

        // The automatic audit trail never records password hashes, so this event is logged on purpose
        await _audit.LogAsync(CurrentUserId, "PasswordReset", "User", user.Id);
    }

    // ---------- Helpers ----------

    private async Task EnsureEmailFreeAsync(string email, int excludeId)
    {
        if (await _users.Query().AnyAsync(u => u.Email == email && u.Id != excludeId))
        {
            throw new ConflictException("A user with this email already exists.",
                new Dictionary<string, string[]> { ["Email"] = new[] { "This email is already used by another user." } });
        }
    }

    private async Task<Role> GetRoleAsync(int roleId) =>
        await _db.Roles.AsNoTracking().FirstOrDefaultAsync(role => role.RoleId == roleId)
        ?? throw Validation("RoleId", "Select a valid role.");

    private static AppException Validation(string field, string message) =>
        new("Validation failed. Please check the highlighted fields.", 400,
            new Dictionary<string, string[]> { [field] = new[] { message } });

    private static IOrderedQueryable<User> ApplySort(IQueryable<User> query, string? sortBy, bool desc)
    {
        return (sortBy?.ToLowerInvariant(), desc) switch
        {
            ("email", false) => query.OrderBy(u => u.Email),
            ("email", true) => query.OrderByDescending(u => u.Email),
            ("role", false) => query.OrderBy(u => u.RoleId),
            ("role", true) => query.OrderByDescending(u => u.RoleId),
            ("status", false) => query.OrderBy(u => u.IsActive),
            ("status", true) => query.OrderByDescending(u => u.IsActive),
            ("created", false) => query.OrderBy(u => u.CreatedAt),
            ("created", true) => query.OrderByDescending(u => u.CreatedAt),
            (_, true) => query.OrderByDescending(u => u.FullName),
            _ => query.OrderBy(u => u.FullName)
        };
    }
}
