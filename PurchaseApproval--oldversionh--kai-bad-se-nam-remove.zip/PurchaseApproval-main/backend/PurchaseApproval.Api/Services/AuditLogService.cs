using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;

namespace PurchaseApproval.Api.Services;

public interface IAuditLogService
{
    Task<PagedResult<AuditLogDto>> GetPagedAsync(AuditLogQuery query, CancellationToken cancellationToken = default);
    Task<AuditFiltersDto> GetFiltersAsync();
    Task<PagedResult<AiDecisionDto>> GetAiDecisionsAsync(AiDecisionQuery query);
}

public class AuditLogService : IAuditLogService
{
    private readonly AppDbContext _db;

    public AuditLogService(AppDbContext db) => _db = db;

    public async Task<PagedResult<AuditLogDto>> GetPagedAsync(
        AuditLogQuery q,
        CancellationToken cancellationToken = default)
    {
        var query = _db.AuditLogs.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            var s = q.Search.Trim();
            query = query.Where(a => a.EntityName.Contains(s) || a.Action.Contains(s)
                                     || (a.NewValues != null && a.NewValues.Contains(s))
                                     || (a.OldValues != null && a.OldValues.Contains(s)));
        }

        if (q.UserId.HasValue)
        {
            var userId = q.UserId.Value;
            query = query.Where(a => a.UserId == userId);
        }

        if (!string.IsNullOrWhiteSpace(q.EntityName))
        {
            var entity = q.EntityName.Trim();
            query = query.Where(a => a.EntityName == entity);
        }

        if (!string.IsNullOrWhiteSpace(q.Action))
        {
            var action = q.Action.Trim();
            query = query.Where(a => a.Action == action);
        }

        if (q.From.HasValue)
        {
            var from = q.From.Value.Date;
            query = query.Where(a => a.Timestamp >= from);
        }

        if (q.To.HasValue)
        {
            var toExclusive = q.To.Value.Date.AddDays(1);   // "to" includes the whole day
            query = query.Where(a => a.Timestamp < toExclusive);
        }

        var totalCount = await query.CountAsync(cancellationToken);
        var totalPages = (int)Math.Ceiling(totalCount / (double)q.PageSize);

        // Avoid issuing a large OFFSET for out-of-range pages.
        if (q.Page > totalPages)
        {
            return new PagedResult<AuditLogDto>
            {
                Page = q.Page,
                PageSize = q.PageSize,
                TotalCount = totalCount
            };
        }

        var skip = (q.Page - 1) * q.PageSize;
        var items = await ApplySort(query, q.SortBy, q.Descending)
            .ThenByDescending(a => a.Id)
            .Skip(skip)
            .Take(q.PageSize)
            .Select(a => new AuditLogDto
            {
                Id = a.Id,
                Timestamp = a.Timestamp,
                UserId = a.UserId,
                UserName = _db.Users.IgnoreQueryFilters()
                    .Where(u => u.Id == a.UserId)
                    .Select(u => u.FullName)
                    .FirstOrDefault() ?? "(not logged in)",
                Action = a.Action,
                EntityName = a.EntityName,
                EntityId = a.EntityId,
                OldValues = a.OldValues,
                NewValues = a.NewValues
            })
            .ToListAsync(cancellationToken);

        return new PagedResult<AuditLogDto>
        {
            Items = items,
            Page = q.Page,
            PageSize = q.PageSize,
            TotalCount = totalCount
        };
    }

    public async Task<AuditFiltersDto> GetFiltersAsync() => new()
    {
        Entities = await _db.AuditLogs.Select(a => a.EntityName).Distinct().OrderBy(n => n).ToListAsync(),
        Actions = await _db.AuditLogs.Select(a => a.Action).Distinct().OrderBy(n => n).ToListAsync()
    };

    private sealed class AiRow
    {
        public int Id { get; set; }
        public DateTime CreatedAt { get; set; }
        public int PurchaseRequestId { get; set; }
        public string RequestNumber { get; set; } = string.Empty;
        public int RequestedBy { get; set; }
        public int? RecommendedVendorId { get; set; }
        public int? FinalVendorId { get; set; }
        public bool WasOverridden { get; set; }
        public string? OverrideReason { get; set; }
    }

    public async Task<PagedResult<AiDecisionDto>> GetAiDecisionsAsync(AiDecisionQuery q)
    {
        var query = _db.AiRecommendationLogs.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            var s = q.Search.Trim();
            query = query.Where(l => l.PurchaseRequest.RequestNumber.Contains(s));
        }

        switch (q.Outcome?.Trim().ToLowerInvariant())
        {
            case "accepted":
                query = query.Where(l => l.FinalVendorId != null && !l.WasOverridden);
                break;
            case "overridden":
                query = query.Where(l => l.WasOverridden);
                break;
            case "unused":
                query = query.Where(l => l.FinalVendorId == null);
                break;
        }

        var page = await query
            .OrderByDescending(l => l.CreatedAt)
            .ThenByDescending(l => l.Id)
            .Select(l => new AiRow
            {
                Id = l.Id,
                CreatedAt = l.CreatedAt,
                PurchaseRequestId = l.PurchaseRequestId,
                RequestNumber = l.PurchaseRequest.RequestNumber,
                RequestedBy = l.RequestedBy,
                RecommendedVendorId = l.RecommendedVendorId,
                FinalVendorId = l.FinalVendorId,
                WasOverridden = l.WasOverridden,
                OverrideReason = l.OverrideReason
            })
            .ToPagedResultAsync(q.Page, q.PageSize);

        var userIds = page.Items.Select(r => r.RequestedBy).Distinct().ToList();
        var vendorIds = page.Items
            .SelectMany(r => new[] { r.RecommendedVendorId, r.FinalVendorId })
            .Where(id => id != null).Select(id => id!.Value).Distinct().ToList();

        var users = await _db.Users.IgnoreQueryFilters()
            .Where(u => userIds.Contains(u.Id))
            .ToDictionaryAsync(u => u.Id, u => u.FullName);
        var vendors = await _db.Vendors.IgnoreQueryFilters()
            .Where(v => vendorIds.Contains(v.Id))
            .ToDictionaryAsync(v => v.Id, v => v.Name);

        string VendorName(int? id) => id != null && vendors.TryGetValue(id.Value, out var name) ? name : "(unknown)";

        return new PagedResult<AiDecisionDto>
        {
            Page = page.Page,
            PageSize = page.PageSize,
            TotalCount = page.TotalCount,
            Items = page.Items.Select(r => new AiDecisionDto
            {
                Id = r.Id,
                CreatedAt = r.CreatedAt,
                PurchaseRequestId = r.PurchaseRequestId,
                RequestNumber = r.RequestNumber,
                RequestedByName = users.TryGetValue(r.RequestedBy, out var user) ? user : "(unknown)",
                RecommendedVendorName = VendorName(r.RecommendedVendorId),
                FinalVendorName = r.FinalVendorId == null ? null : VendorName(r.FinalVendorId),
                Outcome = r.FinalVendorId == null ? "Unused" : r.WasOverridden ? "Overridden" : "Accepted",
                OverrideReason = r.OverrideReason
            }).ToList()
        };
    }

    private static IOrderedQueryable<Models.AuditLog> ApplySort(IQueryable<Models.AuditLog> query, string? sortBy, bool desc)
    {
        return (sortBy?.ToLowerInvariant(), desc) switch
        {
            ("action", false) => query.OrderBy(a => a.Action),
            ("action", true) => query.OrderByDescending(a => a.Action),
            ("entity", false) => query.OrderBy(a => a.EntityName),
            ("entity", true) => query.OrderByDescending(a => a.EntityName),
            ("time", false) => query.OrderBy(a => a.Timestamp),
            _ => query.OrderByDescending(a => a.Timestamp)   // default: newest first
        };
    }
}
