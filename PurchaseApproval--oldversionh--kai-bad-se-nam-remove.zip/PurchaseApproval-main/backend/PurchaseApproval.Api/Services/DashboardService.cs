using System.Globalization;
using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;

namespace PurchaseApproval.Api.Services;

public interface IDashboardService
{
    Task<DashboardDto> GetSummaryAsync();
}

public class DashboardService : IDashboardService
{
    private readonly IRepository<PurchaseRequest> _requests;
    private readonly IRepository<PurchaseOrder> _orders;
    private readonly IRepository<Approval> _approvals;
    private readonly ICurrentUserService _currentUser;

    public DashboardService(
        IRepository<PurchaseRequest> requests,
        IRepository<PurchaseOrder> orders,
        IRepository<Approval> approvals,
        ICurrentUserService currentUser)
    {
        _requests = requests;
        _orders = orders;
        _approvals = approvals;
        _currentUser = currentUser;
    }

    public async Task<DashboardDto> GetSummaryAsync()
    {
        var userId = _currentUser.UserId ?? throw new AppException("You are not logged in.", 401);
        var role = _currentUser.Role;

        var now = DateTime.UtcNow;
        var today = now.Date;
        var monthStart = new DateTime(now.Year, now.Month, 1);
        var nextMonthStart = monthStart.AddMonths(1);
        var firstMonth = monthStart.AddMonths(-5);   // six months including the current one

        var visible = VisibleRequests(userId, role);

        // Requests by status. Every status is listed, even when its count is zero.
        var grouped = await visible
            .GroupBy(r => r.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync();

        var byStatus = Enum.GetValues<RequestStatus>()
            .Select(status => new StatusCountDto
            {
                Status = status,
                Count = grouped.Where(g => g.Status == status).Select(g => g.Count).FirstOrDefault()
            })
            .ToList();

        int CountOf(RequestStatus status) => byStatus.First(s => s.Status == status).Count;
        var totalVisible = byStatus.Sum(s => s.Count);

        var dashboard = new DashboardDto { GeneratedAt = now, RequestsByStatus = byStatus };

        var isOfficer = role == Roles.ProcurementOfficer;
        var isApprover = role == Roles.Manager || role == Roles.Admin;

        // ---- A requester: only their own requests ----
        if (!isOfficer && !isApprover)
        {
            var approvedThisMonth = await CountApprovedThisMonthAsync(visible, monthStart, nextMonthStart);
            var rejected = CountOf(RequestStatus.Rejected);

            dashboard.Scope = "Your own purchase requests.";
            dashboard.Cards = new List<DashboardCardDto>
            {
                Card("total", "My requests", totalVisible, "primary", "Including drafts and cancelled ones", "/requests"),
                Card("awaiting", "Awaiting approval", CountOf(RequestStatus.Submitted), "warning", "Submitted, no decision yet", "/requests"),
                Card("approvedThisMonth", "Approved this month", approvedThisMonth, "success", "Approved since the 1st", "/requests"),
                Card("needsRevision", "Rejected - needs revision", rejected, rejected > 0 ? "danger" : "secondary", "Open the request and use Revise", "/requests")
            };
            dashboard.SpendTitle = "Amount requested per month (submitted requests)";
            dashboard.MonthlySpend = await RequestSeriesAsync(visible, firstMonth);
            return dashboard;
        }

        // ---- Everyone else also sees orders ----
        var orderValue = await ActiveOrders().SumAsync(o => (decimal?)o.TotalAmount) ?? 0m;
        dashboard.SpendTitle = "Order value per month (cancelled orders excluded)";
        dashboard.MonthlySpend = await OrderSeriesAsync(firstMonth);

        if (isOfficer)
        {
            var openOrders = await _orders.Query().CountAsync(o =>
                o.Status == PurchaseOrderStatus.Created || o.Status == PurchaseOrderStatus.Sent);
            var overdue = await _orders.Query().CountAsync(o =>
                (o.Status == PurchaseOrderStatus.Created || o.Status == PurchaseOrderStatus.Sent)
                && o.PromisedDeliveryDate < today);
            var ready = CountOf(RequestStatus.Approved);

            dashboard.Scope = "Approved requests waiting for an order, and the orders in progress.";
            dashboard.Cards = new List<DashboardCardDto>
            {
                Card("readyToOrder", "Approved, ready to order", ready, ready > 0 ? "warning" : "success", "Waiting for a purchase order", "/requests"),
                Card("openOrders", "Open orders", openOrders, "primary", "Created or sent, not yet delivered", "/orders"),
                Card("overdue", "Overdue orders", overdue, overdue > 0 ? "danger" : "success", "Past the promised delivery date", "/orders"),
                Card("poValue", "Total order value", orderValue, "primary", "All orders except cancelled", "/orders", money: true)
            };
            return dashboard;
        }

        // ---- Manager and admin ----
        var pending = await visible.CountAsync(r => r.Status == RequestStatus.Submitted && r.RequesterId != userId);
        var approved = await CountApprovedThisMonthAsync(visible, monthStart, nextMonthStart);

        dashboard.Scope = role == Roles.Admin
            ? "All requests and orders, including drafts."
            : "Submitted requests and orders. Other people's drafts stay private.";
        dashboard.Cards = new List<DashboardCardDto>
        {
            Card("total", "Total requests", totalVisible, "primary", role == Roles.Admin ? "All requests, including drafts" : "Without other people's drafts", "/requests"),
            Card("pending", "Pending approvals", pending, pending > 0 ? "warning" : "success", "Waiting for a decision (not your own)", "/approvals"),
            Card("approvedThisMonth", "Approved this month", approved, "success", "Approved since the 1st", "/requests"),
            Card("poValue", "Total order value", orderValue, "primary", "All orders except cancelled", "/orders", money: true)
        };
        return dashboard;
    }

    // ---------- Helpers ----------

    private static DashboardCardDto Card(
        string key, string label, decimal value, string tone, string hint, string link, bool money = false) =>
        new() { Key = key, Label = label, Value = value, Tone = tone, Hint = hint, Link = link, IsMoney = money };

    // The same visibility rules as the requests list
    private IQueryable<PurchaseRequest> VisibleRequests(int userId, string? role)
    {
        var query = _requests.Query();

        return role switch
        {
            Roles.Admin => query,
            Roles.Manager or Roles.ProcurementOfficer =>
                query.Where(r => r.RequesterId == userId || r.Status != RequestStatus.Draft),
            _ => query.Where(r => r.RequesterId == userId)
        };
    }

    private IQueryable<PurchaseOrder> ActiveOrders() =>
        _orders.Query().Where(o => o.Status != PurchaseOrderStatus.Cancelled);

    // Requests that got an "Approved" decision this month (a request counts once)
    private Task<int> CountApprovedThisMonthAsync(
        IQueryable<PurchaseRequest> visible, DateTime monthStart, DateTime nextMonthStart) =>
        _approvals.Query()
            .Where(a => a.Decision == ApprovalDecision.Approved
                        && a.DecidedAt >= monthStart
                        && a.DecidedAt < nextMonthStart
                        && visible.Any(r => r.Id == a.PurchaseRequestId))
            .Select(a => a.PurchaseRequestId)
            .Distinct()
            .CountAsync();

    private async Task<List<MonthPointDto>> RequestSeriesAsync(IQueryable<PurchaseRequest> visible, DateTime firstMonth)
    {
        var rows = await visible
            .Where(r => r.Status != RequestStatus.Draft && r.Status != RequestStatus.Cancelled && r.CreatedAt >= firstMonth)
            .GroupBy(r => new { r.CreatedAt.Year, r.CreatedAt.Month })
            .Select(g => new { g.Key.Year, g.Key.Month, Amount = g.Sum(r => r.TotalAmount), Count = g.Count() })
            .ToListAsync();

        return FillMonths(firstMonth, rows.Select(r => (r.Year, r.Month, r.Amount, r.Count)));
    }

    private async Task<List<MonthPointDto>> OrderSeriesAsync(DateTime firstMonth)
    {
        var rows = await ActiveOrders()
            .Where(o => o.OrderDate >= firstMonth)
            .GroupBy(o => new { o.OrderDate.Year, o.OrderDate.Month })
            .Select(g => new { g.Key.Year, g.Key.Month, Amount = g.Sum(o => o.TotalAmount), Count = g.Count() })
            .ToListAsync();

        return FillMonths(firstMonth, rows.Select(r => (r.Year, r.Month, r.Amount, r.Count)));
    }

    // Always six points, oldest first. Months without data get zero.
    private static List<MonthPointDto> FillMonths(
        DateTime firstMonth, IEnumerable<(int Year, int Month, decimal Amount, int Count)> rows)
    {
        var lookup = rows.ToDictionary(r => (r.Year, r.Month));
        var points = new List<MonthPointDto>();

        for (var i = 0; i < 6; i++)
        {
            var month = firstMonth.AddMonths(i);
            lookup.TryGetValue((month.Year, month.Month), out var found);
            points.Add(new MonthPointDto
            {
                Month = month.ToString("yyyy-MM", CultureInfo.InvariantCulture),
                Label = month.ToString("MMM yyyy", CultureInfo.InvariantCulture),
                Amount = found.Amount,
                Count = found.Count
            });
        }
        return points;
    }
}
