using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;
using PurchaseApproval.Api.Services;
using Xunit;

namespace PurchaseApproval.Tests;

public class PurchaseRequestServiceTests
{
    // Users: 1 and 2 are requesters, 3 is a manager, 4 is an admin.
    // Products: 1 (price 10), 2 (price 25), 3 (price 4) are active, 4 is inactive.
    // The current user starts as requester 1.
    private static async Task<(PurchaseRequestService Service, AppDbContext Db, FakeCurrentUser Current)> CreateServiceAsync()
    {
        var (db, current) = TestDb.Create(1);
        current.Role = Roles.Requester;

        db.Users.AddRange(
            new User { Id = 1, FullName = "Requester One", Email = "r1@test.example", PasswordHash = "x", Role = UserRole.Requester },
            new User { Id = 2, FullName = "Requester Two", Email = "r2@test.example", PasswordHash = "x", Role = UserRole.Requester },
            new User { Id = 3, FullName = "Manager", Email = "m@test.example", PasswordHash = "x", Role = UserRole.Manager },
            new User { Id = 4, FullName = "Admin", Email = "a@test.example", PasswordHash = "x", Role = UserRole.Admin });
        db.Products.AddRange(
            new Product { Id = 1, Sku = "A", Name = "Product A", Category = "Cat", Unit = "Piece", StandardPrice = 10 },
            new Product { Id = 2, Sku = "B", Name = "Product B", Category = "Cat", Unit = "Piece", StandardPrice = 25 },
            new Product { Id = 3, Sku = "C", Name = "Product C", Category = "Cat", Unit = "Piece", StandardPrice = 4 },
            new Product { Id = 4, Sku = "X", Name = "Retired", Category = "Cat", Unit = "Piece", StandardPrice = 50, IsActive = false });
        await db.SaveChangesAsync();

        var service = new PurchaseRequestService(new Repository<PurchaseRequest>(db), new Repository<Product>(db), current);
        return (service, db, current);
    }

    private static PurchaseRequestInput Input(params (int ProductId, int Quantity)[] items) => new()
    {
        Title = "Test request",
        Items = items.Select(i => new PurchaseRequestItemInput { ProductId = i.ProductId, Quantity = i.Quantity }).ToList()
    };

    [Fact]
    public async Task Create_ComputesPricesAndTotalOnTheServer_AndNumbersTheRequest()
    {
        var (service, _, _) = await CreateServiceAsync();

        var created = await service.CreateAsync(Input((1, 3), (2, 2)));   // 3 x 10 and 2 x 25

        Assert.Equal(RequestStatus.Draft, created.Status);
        Assert.Equal(80m, created.TotalAmount);
        Assert.Equal(2, created.Items.Count);
        Assert.Equal(10m, created.Items.Single(i => i.ProductId == 1).UnitPrice);
        Assert.EndsWith("0001", created.RequestNumber);
        Assert.Equal("Requester One", created.RequesterName);
        Assert.True(created.Permissions.CanEdit);
    }

    [Fact]
    public async Task Create_NumbersCountUpOneByOne()
    {
        var (service, _, _) = await CreateServiceAsync();

        var first = await service.CreateAsync(Input((1, 1)));
        var second = await service.CreateAsync(Input((1, 1)));

        Assert.EndsWith("0001", first.RequestNumber);
        Assert.EndsWith("0002", second.RequestNumber);
    }

    [Fact]
    public async Task Create_WithTheSameProductTwice_IsRejected()
    {
        var (service, _, _) = await CreateServiceAsync();

        var ex = await Assert.ThrowsAsync<AppException>(() => service.CreateAsync(Input((1, 1), (1, 2))));

        Assert.Equal(400, ex.StatusCode);
        Assert.True(ex.Errors!.ContainsKey("Items"));
    }

    [Fact]
    public async Task Create_WithAnInactiveProduct_IsRejected()
    {
        var (service, _, _) = await CreateServiceAsync();

        var ex = await Assert.ThrowsAsync<AppException>(() => service.CreateAsync(Input((4, 1))));

        Assert.True(ex.Errors!.ContainsKey("Items[0].ProductId"));
    }

    [Fact]
    public async Task Create_WithADateInThePast_IsRejected()
    {
        var (service, _, _) = await CreateServiceAsync();
        var input = Input((1, 1));
        input.RequiredByDate = DateTime.UtcNow.AddDays(-5);

        var ex = await Assert.ThrowsAsync<AppException>(() => service.CreateAsync(input));

        Assert.True(ex.Errors!.ContainsKey("RequiredByDate"));
    }

    [Fact]
    public async Task Update_ReplacesTheItems_AndRecalculatesTheTotal()
    {
        var (service, _, _) = await CreateServiceAsync();
        var created = await service.CreateAsync(Input((1, 1), (2, 1)));

        var updated = await service.UpdateAsync(created.Id, Input((1, 5), (3, 1)));   // keep A, drop B, add C

        Assert.Equal(2, updated.Items.Count);
        Assert.Equal(5, updated.Items.Single(i => i.ProductId == 1).Quantity);
        Assert.DoesNotContain(updated.Items, i => i.ProductId == 2);
        Assert.Equal(54m, updated.TotalAmount);   // 5 x 10 + 1 x 4
    }

    [Fact]
    public async Task Update_IsRefused_OnceTheRequestIsSubmitted()
    {
        var (service, _, _) = await CreateServiceAsync();
        var created = await service.CreateAsync(Input((1, 1)));
        await service.SubmitAsync(created.Id);

        await Assert.ThrowsAsync<ConflictException>(() => service.UpdateAsync(created.Id, Input((1, 2))));
    }

    [Fact]
    public async Task Submit_MovesToSubmitted_AndChangesWhatTheUserMayDo()
    {
        var (service, _, _) = await CreateServiceAsync();
        var created = await service.CreateAsync(Input((1, 1)));
        Assert.True(created.Permissions.CanSubmit);

        var submitted = await service.SubmitAsync(created.Id);

        Assert.Equal(RequestStatus.Submitted, submitted.Status);
        Assert.NotNull(submitted.SubmittedAt);
        Assert.False(submitted.Permissions.CanEdit);
        Assert.True(submitted.Permissions.CanCancel);
        await Assert.ThrowsAsync<ConflictException>(() => service.SubmitAsync(created.Id));
    }

    [Fact]
    public async Task OnlyTheOwnerCanChange_AndOthersMayNotEvenSeeADraft()
    {
        var (service, _, current) = await CreateServiceAsync();
        var created = await service.CreateAsync(Input((1, 1)));

        current.UserId = 2;   // another requester
        await Assert.ThrowsAsync<NotFoundException>(() => service.GetByIdAsync(created.Id));

        current.UserId = 4;   // an admin may look, but not change
        current.Role = Roles.Admin;
        var seen = await service.GetByIdAsync(created.Id);
        Assert.False(seen.Permissions.CanEdit);
        await Assert.ThrowsAsync<ForbiddenException>(() => service.UpdateAsync(created.Id, Input((1, 2))));
    }

    [Fact]
    public async Task ListsAreScopedByRole_ManagersDoNotSeeOtherPeoplesDrafts()
    {
        var (service, _, current) = await CreateServiceAsync();
        var draft = await service.CreateAsync(Input((1, 1)));
        var submitted = await service.CreateAsync(Input((2, 1)));
        await service.SubmitAsync(submitted.Id);

        current.UserId = 3;
        current.Role = Roles.Manager;
        var managerList = await service.GetPagedAsync(new PurchaseRequestQuery());
        Assert.Single(managerList.Items);
        Assert.Equal(submitted.Id, managerList.Items[0].Id);
        await Assert.ThrowsAsync<NotFoundException>(() => service.GetByIdAsync(draft.Id));

        current.UserId = 4;
        current.Role = Roles.Admin;
        Assert.Equal(2, (await service.GetPagedAsync(new PurchaseRequestQuery())).TotalCount);

        current.UserId = 2;
        current.Role = Roles.Requester;
        Assert.Empty((await service.GetPagedAsync(new PurchaseRequestQuery())).Items);
    }

    [Fact]
    public async Task Delete_SoftDeletesTheDraftAndItsItems()
    {
        var (service, db, _) = await CreateServiceAsync();
        var created = await service.CreateAsync(Input((1, 1), (2, 1)));

        await service.DeleteAsync(created.Id);

        await Assert.ThrowsAsync<NotFoundException>(() => service.GetByIdAsync(created.Id));
        var request = await db.PurchaseRequests.IgnoreQueryFilters().SingleAsync();
        Assert.True(request.IsDeleted);
        var items = await db.RequestItems.IgnoreQueryFilters().ToListAsync();
        Assert.Equal(2, items.Count);
        Assert.All(items, i => Assert.True(i.IsDeleted));
    }

    [Fact]
    public async Task CancelAndRevise_FollowTheStatusRules()
    {
        var (service, db, _) = await CreateServiceAsync();

        var a = await service.CreateAsync(Input((1, 1)));
        Assert.Equal(RequestStatus.Cancelled, (await service.CancelAsync(a.Id)).Status);
        await Assert.ThrowsAsync<ConflictException>(() => service.CancelAsync(a.Id));   // not twice

        var b = await service.CreateAsync(Input((2, 1)));
        await service.SubmitAsync(b.Id);
        Assert.Equal(RequestStatus.Cancelled, (await service.CancelAsync(b.Id)).Status);   // submitted can be cancelled

        var c = await service.CreateAsync(Input((3, 1)));
        await Assert.ThrowsAsync<ConflictException>(() => service.ReviseAsync(c.Id));   // only rejected ones

        await service.SubmitAsync(c.Id);
        var entity = await db.PurchaseRequests.SingleAsync(r => r.Id == c.Id);
        entity.Status = RequestStatus.Rejected;   // pretend a manager rejected it (Step 9 does this for real)
        await db.SaveChangesAsync();

        var revised = await service.ReviseAsync(c.Id);
        Assert.Equal(RequestStatus.Draft, revised.Status);
        Assert.Null(revised.SubmittedAt);
    }
}
