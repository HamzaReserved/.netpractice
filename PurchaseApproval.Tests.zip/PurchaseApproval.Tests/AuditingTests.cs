using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Models;
using Xunit;

namespace PurchaseApproval.Tests;

public class AuditingTests
{
    private static Vendor NewVendor(string code) =>
        new() { Code = code, Name = "Test Vendor", Email = $"{code}@test.example", Rating = 4 };

    [Fact]
    public async Task Create_FillsCreatedAtAndCreatedBy()
    {
        var (db, _) = TestDb.Create();
        db.Vendors.Add(NewVendor("T1"));
        await db.SaveChangesAsync();

        var vendor = await db.Vendors.SingleAsync();
        Assert.Equal((int?)42, vendor.CreatedBy);
        Assert.True(vendor.CreatedAt > DateTime.UtcNow.AddMinutes(-1));
        Assert.Null(vendor.UpdatedAt);
    }

    [Fact]
    public async Task Create_KeepsAnExplicitCreatedAt()
    {
        var (db, _) = TestDb.Create();
        var past = DateTime.UtcNow.AddDays(-100);
        var vendor = NewVendor("T2");
        vendor.CreatedAt = past;
        db.Vendors.Add(vendor);
        await db.SaveChangesAsync();

        Assert.Equal(past, vendor.CreatedAt);
    }

    [Fact]
    public async Task Update_FillsUpdatedFields_KeepsCreatedBy_AndLogsOldAndNewValues()
    {
        var (db, current) = TestDb.Create();
        db.Vendors.Add(NewVendor("T3"));
        await db.SaveChangesAsync();

        current.UserId = 7;   // a different user edits it
        var vendor = await db.Vendors.SingleAsync();
        vendor.Name = "Renamed Vendor";
        await db.SaveChangesAsync();

        Assert.Equal((int?)42, vendor.CreatedBy);
        Assert.Equal((int?)7, vendor.UpdatedBy);
        Assert.NotNull(vendor.UpdatedAt);

        var log = await db.AuditLogs.SingleAsync(l => l.Action == "Update");
        Assert.Equal(7, log.UserId);
        Assert.Contains("Test Vendor", log.OldValues);
        Assert.Contains("Renamed Vendor", log.NewValues);
    }

    [Fact]
    public async Task Delete_BecomesSoftDelete_AndIsLogged()
    {
        var (db, _) = TestDb.Create();
        db.Vendors.Add(NewVendor("T4"));
        await db.SaveChangesAsync();

        var vendor = await db.Vendors.SingleAsync();
        db.Vendors.Remove(vendor);
        await db.SaveChangesAsync();

        Assert.Empty(await db.Vendors.ToListAsync());                          // hidden from normal queries
        var stillThere = await db.Vendors.IgnoreQueryFilters().SingleAsync();  // but the row still exists
        Assert.True(stillThere.IsDeleted);

        var logs = await db.AuditLogs.ToListAsync();
        Assert.Contains(logs, l => l.Action == "Create" && l.EntityName == "Vendor");
        Assert.Contains(logs, l => l.Action == "Delete" && l.EntityName == "Vendor");
    }

    [Fact]
    public async Task PasswordHash_IsNeverWrittenToTheAuditLog()
    {
        var (db, _) = TestDb.Create();
        db.Users.Add(new User
        {
            FullName = "Test User",
            Email = "t@test.example",
            PasswordHash = "SECRET-HASH",
            Role = UserRole.Requester
        });
        await db.SaveChangesAsync();

        var log = await db.AuditLogs.SingleAsync();
        Assert.Equal("Create", log.Action);
        Assert.Equal("User", log.EntityName);
        Assert.DoesNotContain("SECRET-HASH", log.NewValues);
    }

    [Fact]
    public async Task NoLoggedInUser_MeansNoAuditLogRows()
    {
        var (db, _) = TestDb.Create(userId: null);   // like the seeder
        db.Vendors.Add(NewVendor("T5"));
        await db.SaveChangesAsync();

        Assert.Empty(await db.AuditLogs.ToListAsync());
    }
}
