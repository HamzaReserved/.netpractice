using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;
using PurchaseApproval.Api.Services;
using Xunit;

namespace PurchaseApproval.Tests;

public class ProductServiceTests
{
    private static (ProductService Service, AppDbContext Db) CreateService()
    {
        var (db, _) = TestDb.Create();
        var service = new ProductService(new Repository<Product>(db), new Repository<RequestItem>(db));
        return (service, db);
    }

    private static ProductRequest Request(string sku = "P-1", string category = "Furniture", decimal price = 10) =>
        new() { Sku = sku, Name = $"Product {sku}", Category = category, Unit = "Piece", StandardPrice = price };

    // Creates a purchase request with one item that uses the product
    private static async Task AddRequestUsing(AppDbContext db, int productId, RequestStatus status, string number)
    {
        var product = await db.Products.SingleAsync(p => p.Id == productId);
        var requester = await db.Users.FirstOrDefaultAsync()
            ?? new User { FullName = "R", Email = "r@test.example", PasswordHash = "x" };

        db.PurchaseRequests.Add(new PurchaseRequest
        {
            RequestNumber = number,
            Title = "Test",
            Requester = requester,
            Status = status,
            Items = { new RequestItem { Product = product, Quantity = 1 } }
        });
        await db.SaveChangesAsync();
    }

    [Fact]
    public async Task Create_TrimsAndUppercasesTheSku()
    {
        var (service, _) = CreateService();

        var created = await service.CreateAsync(Request(" lap-9 "));

        Assert.Equal("LAP-9", created.Sku);
    }

    [Fact]
    public async Task Create_WithDuplicateSku_ThrowsConflictWithAFieldError()
    {
        var (service, _) = CreateService();
        await service.CreateAsync(Request("P-1"));

        var ex = await Assert.ThrowsAsync<ConflictException>(() => service.CreateAsync(Request("p-1")));

        Assert.NotNull(ex.Errors);
        Assert.True(ex.Errors!.ContainsKey("Sku"));
    }

    [Fact]
    public async Task GetPaged_FiltersByCategory_SearchesAndSortsByPrice()
    {
        var (service, _) = CreateService();
        await service.CreateAsync(Request("A", "Furniture", 300));
        await service.CreateAsync(Request("B", "Furniture", 120));
        await service.CreateAsync(Request("C", "Stationery", 5));

        var furniture = await service.GetPagedAsync(new ProductQuery { Category = "Furniture", SortBy = "price", Descending = true });
        Assert.Equal(2, furniture.TotalCount);
        Assert.Equal("A", furniture.Items[0].Sku);

        var search = await service.GetPagedAsync(new ProductQuery { Search = "Product C" });
        Assert.Single(search.Items);
    }

    [Fact]
    public async Task Delete_IsBlocked_WhenTheProductIsUsedInAnOpenRequest()
    {
        var (service, db) = CreateService();
        var product = await service.CreateAsync(Request("D"));
        await AddRequestUsing(db, product.Id, RequestStatus.Draft, "PR-1");

        await Assert.ThrowsAsync<ConflictException>(() => service.DeleteAsync(product.Id));
    }

    [Fact]
    public async Task Delete_IsAllowed_WhenOnlyCompletedRequestsUseTheProduct()
    {
        var (service, db) = CreateService();
        var product = await service.CreateAsync(Request("E"));
        await AddRequestUsing(db, product.Id, RequestStatus.PoCreated, "PR-2");

        await service.DeleteAsync(product.Id);

        await Assert.ThrowsAsync<NotFoundException>(() => service.GetByIdAsync(product.Id));
    }

    [Fact]
    public async Task GetCategories_ReturnsDistinctSortedNames()
    {
        var (service, _) = CreateService();
        await service.CreateAsync(Request("A", "Stationery"));
        await service.CreateAsync(Request("B", "Furniture"));
        await service.CreateAsync(Request("C", "Furniture"));

        var categories = await service.GetCategoriesAsync();

        Assert.Equal(new[] { "Furniture", "Stationery" }, categories);
    }
}
