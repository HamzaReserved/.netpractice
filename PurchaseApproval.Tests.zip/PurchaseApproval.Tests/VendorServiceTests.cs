using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;
using PurchaseApproval.Api.Services;
using Xunit;

namespace PurchaseApproval.Tests;

public class VendorServiceTests
{
    private static (VendorService Service, AppDbContext Db) CreateService()
    {
        var (db, _) = TestDb.Create();
        var service = new VendorService(new Repository<Vendor>(db), new Repository<PurchaseOrder>(db));
        return (service, db);
    }

    private static VendorRequest Request(string code = "V100", string email = "v100@test.example") =>
        new() { Code = code, Name = "Acme Supplies", Email = email, Rating = 4 };

    [Fact]
    public async Task Create_TrimsAndUppercasesTheCode()
    {
        var (service, _) = CreateService();

        var created = await service.CreateAsync(Request(" v100 "));

        Assert.Equal("V100", created.Code);
        Assert.True(created.Id > 0);
    }

    [Fact]
    public async Task Create_WithDuplicateCode_ThrowsConflictWithAFieldError()
    {
        var (service, _) = CreateService();
        await service.CreateAsync(Request("V100", "a@test.example"));

        var ex = await Assert.ThrowsAsync<ConflictException>(
            () => service.CreateAsync(Request("v100", "b@test.example")));

        Assert.NotNull(ex.Errors);
        Assert.True(ex.Errors!.ContainsKey("Code"));
    }

    [Fact]
    public async Task Update_AllowsKeepingOwnValues_ButNotAnotherVendorsEmail()
    {
        var (service, _) = CreateService();
        var first = await service.CreateAsync(Request("V1", "one@test.example"));
        await service.CreateAsync(Request("V2", "two@test.example"));

        var same = Request("V1", "one@test.example");
        same.Name = "Renamed";
        var updated = await service.UpdateAsync(first.Id, same);
        Assert.Equal("Renamed", updated.Name);

        await Assert.ThrowsAsync<ConflictException>(
            () => service.UpdateAsync(first.Id, Request("V1", "two@test.example")));
    }

    [Fact]
    public async Task GetPaged_SearchesSortsAndPages()
    {
        var (service, _) = CreateService();
        for (int i = 1; i <= 12; i++)
            await service.CreateAsync(new VendorRequest { Code = $"A{i:00}", Name = $"Alpha {i:00}", Email = $"a{i}@test.example", Rating = 3 });
        for (int i = 1; i <= 3; i++)
            await service.CreateAsync(new VendorRequest { Code = $"B{i:00}", Name = $"Beta {i:00}", Email = $"b{i}@test.example", Rating = 5 });

        var page2 = await service.GetPagedAsync(new VendorQuery { Search = "Alpha", Page = 2, PageSize = 5 });
        Assert.Equal(12, page2.TotalCount);
        Assert.Equal(5, page2.Items.Count);
        Assert.Equal("Alpha 06", page2.Items[0].Name);

        var newestFirst = await service.GetPagedAsync(new VendorQuery { Search = "Alpha", SortBy = "name", Descending = true });
        Assert.Equal("Alpha 12", newestFirst.Items[0].Name);

        var topRated = await service.GetPagedAsync(new VendorQuery { SortBy = "rating", Descending = true, PageSize = 3 });
        Assert.All(topRated.Items, v => Assert.Equal(5m, v.Rating));
    }

    [Fact]
    public async Task Delete_IsBlocked_WhenTheVendorHasAnOpenPurchaseOrder()
    {
        var (service, db) = CreateService();
        var vendor = await service.CreateAsync(Request("V9", "v9@test.example"));
        var entity = await db.Vendors.SingleAsync();
        db.PurchaseOrders.Add(new PurchaseOrder
        {
            PoNumber = "PO-1",
            Vendor = entity,
            PurchaseRequest = new PurchaseRequest
            {
                RequestNumber = "PR-1",
                Title = "Test",
                Requester = new User { FullName = "R", Email = "r@test.example", PasswordHash = "x" }
            },
            OrderDate = DateTime.UtcNow,
            PromisedDeliveryDate = DateTime.UtcNow.AddDays(5),
            Status = PurchaseOrderStatus.Sent
        });
        await db.SaveChangesAsync();

        await Assert.ThrowsAsync<ConflictException>(() => service.DeleteAsync(vendor.Id));
    }

    [Fact]
    public async Task Delete_HidesTheVendor_ButKeepsTheRow()
    {
        var (service, db) = CreateService();
        var vendor = await service.CreateAsync(Request("V8", "v8@test.example"));

        await service.DeleteAsync(vendor.Id);

        await Assert.ThrowsAsync<NotFoundException>(() => service.GetByIdAsync(vendor.Id));
        Assert.Single(await db.Vendors.IgnoreQueryFilters().ToListAsync());
    }
}
