using Microsoft.EntityFrameworkCore;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Services;

namespace PurchaseApproval.Tests;

public class FakeCurrentUser : ICurrentUserService
{
    public int? UserId { get; set; }
    public string? Role { get; set; }
}

public static class TestDb
{
    // A fresh, empty, throw-away database for every test
    public static (AppDbContext Db, FakeCurrentUser Current) Create(int? userId = 42)
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        var current = new FakeCurrentUser { UserId = userId };
        return (new AppDbContext(options, current), current);
    }
}
