using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PurchaseApproval.Api.Common;
using PurchaseApproval.Api.Constants;
using PurchaseApproval.Api.Data;
using PurchaseApproval.Api.Dtos;
using PurchaseApproval.Api.Models;
using PurchaseApproval.Api.Repositories;
using PurchaseApproval.Api.Services;
using Xunit;

namespace PurchaseApproval.Tests;

// ---------- The maths on its own ----------
public class VendorScorerTests
{
    private static readonly RecommendationOptions Defaults = new();

    [Fact]
    public void PriceScore_GivesTheCheapestOneAndHalfForDouble()
    {
        Assert.Equal(1m, VendorScorer.PriceScore(100m, 100m));
        Assert.Equal(0.5m, VendorScorer.PriceScore(200m, 100m));
    }

    [Fact]
    public void DeliveryScore_IsTheOnTimeShare_AndNeutralWithoutHistory()
    {
        Assert.Equal(0.75m, VendorScorer.DeliveryScore(3, 4));
        Assert.Equal(0m, VendorScorer.DeliveryScore(0, 3));
        Assert.Equal(0.5m, VendorScorer.DeliveryScore(0, 0));
    }

    [Fact]
    public void RatingScore_IsTheRatingOutOfFive_AndStaysBetweenZeroAndOne()
    {
        Assert.Equal(0.9m, VendorScorer.RatingScore(4.5m));
        Assert.Equal(1m, VendorScorer.RatingScore(7m));
        Assert.Equal(0m, VendorScorer.RatingScore(-1m));
    }

    [Fact]
    public void TotalScore_AppliesTheDefaultWeights()
    {
        // 100 x (0.40 x 1.00 + 0.35 x 0.75 + 0.25 x 0.90) = 88.75, shown as 88.8
        Assert.Equal(88.8m, VendorScorer.TotalScore(1.00m, 0.75m, 0.90m, Defaults));
        Assert.Equal(100m, VendorScorer.TotalScore(1m, 1m, 1m, Defaults));
        Assert.Equal(0m, VendorScorer.TotalScore(0m, 0m, 0m, Defaults));
    }

    [Fact]
    public void TotalScore_ScalesWeightsThatDoNotAddUpToOne()
    {
        var options = new RecommendationOptions { PriceWeight = 2m, DeliveryWeight = 2m, RatingWeight = 1m };

        // Same as 0.4 / 0.4 / 0.2: price 1, the rest 0, gives 40
        Assert.Equal(40m, VendorScorer.TotalScore(1m, 0m, 0m, options));
    }

    [Fact]
    public void Confidence_NeedsBothEnoughHistoryAndAClearLead()
    {
        // 5 orders and a 20 point lead: full confidence
        Assert.Equal((1.00m, "High"), VendorScorer.Confidence(5, 90m, 70m, Defaults));

        // Only vendor: the lead cannot be doubted, history still counts (2 of 5 = 0.4)
        Assert.Equal((0.64m, "Medium"), VendorScorer.Confidence(2, 80m, null, Defaults));

        // 2 orders and a 7.5 point lead: 0.6 x 0.4 + 0.4 x 0.5 = 0.44
        Assert.Equal((0.44m, "Low"), VendorScorer.Confidence(2, 80m, 72.5m, Defaults));

        // No history at all and no lead: nothing to trust
        Assert.Equal((0.00m, "Low"), VendorScorer.Confidence(0, 70m, 70m, Defaults));
    }
}

// ---------- The service, with a small invented market ----------
public class RecommendationServiceTests
{
    private sealed record Harness(
        RecommendationService Recommendations,
        PurchaseOrderService Orders,
        PurchaseRequestService Requests,
        AppDbContext Db,
        FakeCurrentUser Current);

    // Users: 1 requester, 3 officer. Product 1 has quotes from three vendors, product 2 from nobody.
    // Vendor 1 "Alpha": cheapest (100), rating 3.0.   Vendor 2 "Bravo": 110, rating 4.5.
    // Vendor 3 "Charlie": 105, rating 4.0.
    private static async Task<Harness> CreateAsync()
    {
        var (db, current) = TestDb.Create(1);
        current.Role = Roles.Requester;

        db.Users.AddRange(
            new User { Id = 1, FullName = "Requester", Email = "r@test.example", PasswordHash = "x", Role = UserRole.Requester },
            new User { Id = 3, FullName = "Officer", Email = "o@test.example", PasswordHash = "x", Role = UserRole.ProcurementOfficer });
        db.Products.AddRange(
            new Product { Id = 1, Sku = "A", Name = "Product A", Category = "Cat", Unit = "Piece", StandardPrice = 10 },
            new Product { Id = 2, Sku = "B", Name = "Product B", Category = "Cat", Unit = "Piece", StandardPrice = 25 });
        db.Vendors.AddRange(
            new Vendor { Id = 1, Code = "V1", Name = "Alpha", Email = "a@v.example", Rating = 3.0m },
            new Vendor { Id = 2, Code = "V2", Name = "Bravo", Email = "b@v.example", Rating = 4.5m },
            new Vendor { Id = 3, Code = "V3", Name = "Charlie", Email = "c@v.example", Rating = 4.0m });
        db.VendorProducts.AddRange(
            new VendorProduct { VendorId = 1, ProductId = 1, QuotedPrice = 100, LeadTimeDays = 5 },
            new VendorProduct { VendorId = 2, ProductId = 1, QuotedPrice = 110, LeadTimeDays = 3 },
            new VendorProduct { VendorId = 3, ProductId = 1, QuotedPrice = 105, LeadTimeDays = 7 });
        await db.SaveChangesAsync();

        var requests = new PurchaseRequestService(new Repository<PurchaseRequest>(db), new Repository<Product>(db), current);
        var quotes = new VendorQuoteService(new Repository<RequestItem>(db), new Repository<VendorProduct>(db));
        var recommendations = new RecommendationService(
            db, new Repository<PurchaseRequest>(db), new Repository<PurchaseOrder>(db), quotes,
            Options.Create(new RecommendationOptions()), current);
        var orders = new PurchaseOrderService(
            new Repository<PurchaseOrder>(db), new Repository<PurchaseRequest>(db), new Repository<Product>(db),
            quotes, current, recommendations);

        return new Harness(recommendations, orders, requests, db, current);
    }

    // A request for 1 x product (1 by default), made by requester 1, optionally submitted and approved
    private static async Task<int> RequestAsync(Harness h, int productId = 1, bool submit = true, bool approve = true)
    {
        h.Current.UserId = 1;
        h.Current.Role = Roles.Requester;

        var created = await h.Requests.CreateAsync(new PurchaseRequestInput
        {
            Title = "Test",
            Items = new() { new PurchaseRequestItemInput { ProductId = productId, Quantity = 1 } }
        });
        if (submit) await h.Requests.SubmitAsync(created.Id);
        if (approve)
        {
            var entity = await h.Db.PurchaseRequests.SingleAsync(r => r.Id == created.Id);
            entity.Status = RequestStatus.Approved;
            await h.Db.SaveChangesAsync();
        }
        return created.Id;
    }

    private static void BecomeOfficer(Harness h)
    {
        h.Current.UserId = 3;
        h.Current.Role = Roles.ProcurementOfficer;
    }

    // Past delivered orders for a vendor: some on time, some late
    private static async Task AddHistoryAsync(Harness h, int vendorId, int onTime, int late, int ageInDays = 30)
    {
        var today = DateTime.UtcNow.Date;
        var number = 0;

        for (var i = 0; i < onTime + late; i++)
        {
            var isLate = i >= onTime;
            h.Db.PurchaseOrders.Add(new PurchaseOrder
            {
                PoNumber = $"PO-H{vendorId}-{++number}-{ageInDays}",
                PurchaseRequestId = 999,
                VendorId = vendorId,
                OrderDate = today.AddDays(-ageInDays),
                PromisedDeliveryDate = today.AddDays(-ageInDays + 10),
                DeliveredDate = today.AddDays(isLate ? -ageInDays + 15 : -ageInDays + 8),
                Status = PurchaseOrderStatus.Delivered
            });
        }
        await h.Db.SaveChangesAsync();
    }

    // Alpha: cheap but 1 of 4 on time. Bravo: 4 of 4 on time. Charlie: no history.
    private static async Task<Harness> MarketWithHistoryAsync()
    {
        var h = await CreateAsync();
        await AddHistoryAsync(h, 1, onTime: 1, late: 3);
        await AddHistoryAsync(h, 2, onTime: 4, late: 0);
        return h;
    }

    [Fact]
    public async Task Evaluate_RanksByTheWeightedScore_NotJustByPrice()
    {
        var h = await MarketWithHistoryAsync();
        var id = await RequestAsync(h);
        BecomeOfficer(h);

        var result = await h.Recommendations.EvaluateAsync(id);

        // Bravo: 100 x (0.40 x 0.9091 + 0.35 x 1.00 + 0.25 x 0.90) = 93.9
        // Charlie: 100 x (0.40 x 0.9524 + 0.35 x 0.50 + 0.25 x 0.80) = 75.6
        // Alpha, the cheapest: 100 x (0.40 x 1.00 + 0.35 x 0.25 + 0.25 x 0.60) = 63.8
        Assert.Equal(new[] { "Bravo", "Charlie", "Alpha" }, result.Vendors.Select(v => v.VendorName).ToArray());
        Assert.Equal(new[] { 93.9m, 75.6m, 63.8m }, result.Vendors.Select(v => v.TotalScore).ToArray());
        Assert.Equal(new[] { 1, 2, 3 }, result.Vendors.Select(v => v.Rank).ToArray());
        Assert.True(result.Vendors[0].IsRecommended);
        Assert.False(result.Vendors[1].IsRecommended);
    }

    [Fact]
    public async Task Evaluate_ExplainsEachRankingInPlainWords()
    {
        var h = await MarketWithHistoryAsync();
        var id = await RequestAsync(h);
        BecomeOfficer(h);

        var result = await h.Recommendations.EvaluateAsync(id);

        var bravo = result.Vendors.Single(v => v.VendorName == "Bravo");
        Assert.Contains("4 of 4 recent orders delivered on time", bravo.Explanation);
        Assert.Contains("10.0% above the cheapest", bravo.Explanation);

        var charlie = result.Vendors.Single(v => v.VendorName == "Charlie");
        Assert.Contains("no delivery history", charlie.Explanation);
        Assert.Equal(0, charlie.OrdersConsidered);
        Assert.Equal(0.5m, charlie.DeliveryScore);   // the neutral score

        var alpha = result.Vendors.Single(v => v.VendorName == "Alpha");
        Assert.Contains("lowest total price", alpha.Explanation);
        Assert.Contains("1 of 4 recent orders delivered on time", alpha.Explanation);

        Assert.Contains("Recommended: Bravo", result.Summary);
        Assert.Contains("delivery record", result.Summary);   // its biggest advantage over Charlie
    }

    [Fact]
    public async Task Evaluate_ReportsConfidence_FromHistoryAndMargin()
    {
        var h = await MarketWithHistoryAsync();
        var id = await RequestAsync(h);
        BecomeOfficer(h);

        var result = await h.Recommendations.EvaluateAsync(id);

        // 4 orders for the top vendor = 0.8 history, an 18.3 point lead = full margin: 0.6 x 0.8 + 0.4 x 1 = 0.88
        Assert.Equal(0.88m, result.ConfidenceScore);
        Assert.Equal("High", result.Confidence);
        Assert.Equal(0.40m, result.Weights.Price);
        Assert.Equal(0.35m, result.Weights.Delivery);
        Assert.Equal(0.25m, result.Weights.Rating);
    }

    [Fact]
    public async Task Evaluate_SavesAnAnalysisInTheLog()
    {
        var h = await MarketWithHistoryAsync();
        var id = await RequestAsync(h);
        BecomeOfficer(h);

        var result = await h.Recommendations.EvaluateAsync(id);

        var log = await h.Db.AiRecommendationLogs.SingleAsync();
        Assert.Equal(result.LogId, log.Id);
        Assert.Equal(id, log.PurchaseRequestId);
        Assert.Equal(3, log.RequestedBy);
        Assert.Equal(2, log.RecommendedVendorId);   // Bravo
        Assert.Null(log.FinalVendorId);
        Assert.Contains("\"vendors\"", log.OutputJson);
        Assert.Contains("\"eligibleVendorIds\"", log.InputJson);
    }

    [Fact]
    public async Task Evaluate_CountsOpenOrdersThatAreAlreadyLate_AsLate()
    {
        var h = await MarketWithHistoryAsync();
        var id = await RequestAsync(h);
        BecomeOfficer(h);
        var today = DateTime.UtcNow.Date;
        h.Db.PurchaseOrders.Add(new PurchaseOrder
        {
            PoNumber = "PO-OPEN", PurchaseRequestId = 999, VendorId = 3,
            OrderDate = today.AddDays(-10), PromisedDeliveryDate = today.AddDays(-3),
            Status = PurchaseOrderStatus.Sent
        });
        await h.Db.SaveChangesAsync();

        var result = await h.Recommendations.EvaluateAsync(id);

        var charlie = result.Vendors.Single(v => v.VendorName == "Charlie");
        Assert.Equal(1, charlie.OrdersConsidered);
        Assert.Equal(0, charlie.OnTimeOrders);
        Assert.Equal(0m, charlie.DeliveryScore);
        Assert.Equal("Charlie", result.Vendors[2].VendorName);   // the late order drops it to last place
    }

    [Fact]
    public async Task Evaluate_IgnoresOldOrdersAndCancelledOnes()
    {
        var h = await MarketWithHistoryAsync();
        var id = await RequestAsync(h);
        BecomeOfficer(h);
        await AddHistoryAsync(h, 3, onTime: 2, late: 0, ageInDays: 400);   // older than the 365 day window
        h.Db.PurchaseOrders.Add(new PurchaseOrder
        {
            PoNumber = "PO-CANCELLED", PurchaseRequestId = 999, VendorId = 3,
            OrderDate = DateTime.UtcNow.Date.AddDays(-20), PromisedDeliveryDate = DateTime.UtcNow.Date.AddDays(-10),
            Status = PurchaseOrderStatus.Cancelled
        });
        await h.Db.SaveChangesAsync();

        var result = await h.Recommendations.EvaluateAsync(id);

        Assert.Equal(0, result.Vendors.Single(v => v.VendorName == "Charlie").OrdersConsidered);
    }

    [Fact]
    public async Task Evaluate_OnlyWorksForApprovedRequests()
    {
        var h = await CreateAsync();
        var submitted = await RequestAsync(h, approve: false);
        var draft = await RequestAsync(h, submit: false, approve: false);
        BecomeOfficer(h);

        await Assert.ThrowsAsync<ConflictException>(() => h.Recommendations.EvaluateAsync(submitted));
        await Assert.ThrowsAsync<NotFoundException>(() => h.Recommendations.EvaluateAsync(draft));
    }

    [Fact]
    public async Task Evaluate_WithNoEligibleVendor_SaysSoAndSavesNoLog()
    {
        var h = await CreateAsync();
        var id = await RequestAsync(h, productId: 2);   // nobody quotes product 2
        BecomeOfficer(h);

        var result = await h.Recommendations.EvaluateAsync(id);

        Assert.Empty(result.Vendors);
        Assert.Null(result.LogId);
        Assert.Contains("No active vendor", result.Summary);
        Assert.Empty(await h.Db.AiRecommendationLogs.ToListAsync());
    }

    [Fact]
    public async Task CreatingAnOrder_WithTheRecommendedVendor_RecordsAnAcceptedDecision()
    {
        var h = await MarketWithHistoryAsync();
        var id = await RequestAsync(h);
        BecomeOfficer(h);
        var analysis = await h.Recommendations.EvaluateAsync(id);

        var order = await h.Orders.CreateAsync(new PurchaseOrderCreateInput
        {
            PurchaseRequestId = id,
            VendorId = 2,   // Bravo, the recommended one
            PromisedDeliveryDate = DateTime.UtcNow.Date.AddDays(5),
            RecommendationLogId = analysis.LogId
        });

        Assert.Equal("Bravo", order.VendorName);
        var log = await h.Db.AiRecommendationLogs.SingleAsync();
        Assert.Equal(2, log.FinalVendorId);
        Assert.False(log.WasOverridden);
        Assert.Null(log.OverrideReason);
    }

    [Fact]
    public async Task ChoosingAnotherVendor_NeedsAReason_AndCreatesNothingWithoutIt()
    {
        var h = await MarketWithHistoryAsync();
        var id = await RequestAsync(h);
        BecomeOfficer(h);
        var analysis = await h.Recommendations.EvaluateAsync(id);

        var input = new PurchaseOrderCreateInput
        {
            PurchaseRequestId = id,
            VendorId = 3,   // Charlie, not the recommendation
            PromisedDeliveryDate = DateTime.UtcNow.Date.AddDays(5),
            RecommendationLogId = analysis.LogId
        };

        var ex = await Assert.ThrowsAsync<AppException>(() => h.Orders.CreateAsync(input));
        Assert.True(ex.Errors!.ContainsKey("OverrideReason"));
        Assert.Empty(await h.Db.PurchaseOrders.Where(o => o.PurchaseRequestId == id).ToListAsync());
        Assert.Equal(RequestStatus.Approved, (await h.Requests.GetByIdAsync(id)).Status);

        input.OverrideReason = "  Closest to our warehouse  ";
        var order = await h.Orders.CreateAsync(input);

        Assert.Equal("Charlie", order.VendorName);
        var log = await h.Db.AiRecommendationLogs.SingleAsync();
        Assert.Equal(3, log.FinalVendorId);
        Assert.Equal(2, log.RecommendedVendorId);
        Assert.True(log.WasOverridden);
        Assert.Equal("Closest to our warehouse", log.OverrideReason);
    }

    [Fact]
    public async Task AnAnalysis_CannotBeUsedTwice_OrForAnotherRequest()
    {
        var h = await MarketWithHistoryAsync();
        var first = await RequestAsync(h);
        var second = await RequestAsync(h);
        BecomeOfficer(h);
        var analysis = await h.Recommendations.EvaluateAsync(first);

        // Belongs to a different request
        var wrong = await Assert.ThrowsAsync<AppException>(() => h.Orders.CreateAsync(new PurchaseOrderCreateInput
        {
            PurchaseRequestId = second, VendorId = 2,
            PromisedDeliveryDate = DateTime.UtcNow.Date.AddDays(5), RecommendationLogId = analysis.LogId
        }));
        Assert.True(wrong.Errors!.ContainsKey("RecommendationLogId"));

        // Used once, then cancelled, then tried again
        var order = await h.Orders.CreateAsync(new PurchaseOrderCreateInput
        {
            PurchaseRequestId = first, VendorId = 2,
            PromisedDeliveryDate = DateTime.UtcNow.Date.AddDays(5), RecommendationLogId = analysis.LogId
        });
        await h.Orders.CancelAsync(order.Id);

        await Assert.ThrowsAsync<ConflictException>(() => h.Orders.CreateAsync(new PurchaseOrderCreateInput
        {
            PurchaseRequestId = first, VendorId = 2,
            PromisedDeliveryDate = DateTime.UtcNow.Date.AddDays(5), RecommendationLogId = analysis.LogId
        }));
    }

    [Fact]
    public async Task CreatingAnOrder_WithoutAnAnalysis_StillWorks_TheAdviceIsOnlyAdvice()
    {
        var h = await MarketWithHistoryAsync();
        var id = await RequestAsync(h);
        BecomeOfficer(h);

        var order = await h.Orders.CreateAsync(new PurchaseOrderCreateInput
        {
            PurchaseRequestId = id, VendorId = 1,
            PromisedDeliveryDate = DateTime.UtcNow.Date.AddDays(5)
        });

        Assert.Equal("Alpha", order.VendorName);
        Assert.Empty(await h.Db.AiRecommendationLogs.ToListAsync());
    }
}
